/*
 * Copyright 2014 NAVER Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.qm.smartsight.kernel.core.security;

import com.qm.smartsight.kernel.core.applicationmap.ApplicationMap;
import com.qm.smartsight.kernel.core.vo.Application;
//import com.qm.smartsight.kernel.core.websocket.message.RequestMessage;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.WebSocketSession;

/**
 * @author minwoo.jung
 */
public interface ServerMapDataFilter {

    boolean filter(Application application);

//    boolean filter(WebSocketSession webSocketSession, RequestMessage requestMessage);
//
//    CloseStatus getCloseStatus(RequestMessage requestMessage);

    ApplicationMap dataFiltering(ApplicationMap map);
}
