/**
 * Audit specific code.
 */
package com.qm.smartsight.kernel.config.audit;
