/*
 * Copyright 2014 NAVER Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.qm.smartsight.kernel.core.alarm;

import com.navercorp.pinpoint.common.server.bo.stat.CpuLoadBo;
import com.navercorp.pinpoint.common.server.bo.stat.JvmGcBo;
import com.qm.smartsight.kernel.core.alarm.collector.AgentStatDataCollector;
import com.qm.smartsight.kernel.core.alarm.collector.DataCollector;
import com.qm.smartsight.kernel.core.alarm.collector.MapStatisticsCallerDataCollector;
import com.qm.smartsight.kernel.core.alarm.collector.ResponseTimeDataCollector;
import com.qm.smartsight.kernel.core.dao.hbase.HbaseApplicationIndexDao;
import com.qm.smartsight.kernel.core.dao.hbase.HbaseMapResponseTimeDao;
import com.qm.smartsight.kernel.core.dao.hbase.HbaseMapStatisticsCallerDao;
import com.qm.smartsight.kernel.core.dao.stat.AgentStatDao;
import com.qm.smartsight.kernel.core.vo.Application;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * @author minwoo.jung
 */
@Component
public class DataCollectorFactory {

    public final static long SLOT_INTERVAL_FIVE_MIN = 300000;

    public final static long SLOT_INTERVAL_THREE_MIN = 180000;

    @Autowired
    private HbaseMapResponseTimeDao hbaseMapResponseTimeDao;

    @Autowired
    @Qualifier("jvmGcDaoFactory")
    private AgentStatDao<JvmGcBo> jvmGcDao;

    @Autowired
    @Qualifier("cpuLoadDaoFactory")
    private AgentStatDao<CpuLoadBo> cpuLoadDao;

    @Autowired
    private HbaseApplicationIndexDao hbaseApplicationIndexDao;

    @Autowired
    private HbaseMapStatisticsCallerDao mapStatisticsCallerDao;

    public DataCollector createDataCollector(CheckerCategory checker, Application application, long timeSlotEndTime) {
        switch (checker.getDataCollectorCategory()) {
        case RESPONSE_TIME:
            return new ResponseTimeDataCollector(DataCollectorCategory.RESPONSE_TIME, application, hbaseMapResponseTimeDao, timeSlotEndTime, SLOT_INTERVAL_FIVE_MIN);
        case AGENT_STAT:
            return new AgentStatDataCollector(DataCollectorCategory.AGENT_STAT, application, jvmGcDao, cpuLoadDao, hbaseApplicationIndexDao, timeSlotEndTime, SLOT_INTERVAL_FIVE_MIN);
        case CALLER_STAT:
            return new MapStatisticsCallerDataCollector(DataCollectorCategory.CALLER_STAT, application, mapStatisticsCallerDao, timeSlotEndTime, SLOT_INTERVAL_FIVE_MIN);
        }

        throw new IllegalArgumentException("unable to create DataCollector : " + checker.getName());

    }

    public enum DataCollectorCategory {
        RESPONSE_TIME,
        AGENT_STAT,
        CALLER_STAT
    }
}
