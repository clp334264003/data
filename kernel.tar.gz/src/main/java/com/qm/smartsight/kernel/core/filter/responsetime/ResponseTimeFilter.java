package com.qm.smartsight.kernel.core.filter.responsetime;

/**
 * @author emeroad
 */
public interface ResponseTimeFilter {
    boolean ACCEPT = true;
    boolean REJECT = false;

    boolean accept(long elapsed);


}
