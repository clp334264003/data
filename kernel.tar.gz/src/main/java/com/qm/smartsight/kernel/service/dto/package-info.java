/**
 * Data Transfer Objects.
 */
package com.qm.smartsight.kernel.service.dto;
