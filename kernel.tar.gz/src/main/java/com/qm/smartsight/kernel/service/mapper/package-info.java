/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package com.qm.smartsight.kernel.service.mapper;
