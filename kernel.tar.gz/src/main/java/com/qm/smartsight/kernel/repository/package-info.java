/**
 * Spring Data JPA repositories.
 */
package com.qm.smartsight.kernel.repository;
