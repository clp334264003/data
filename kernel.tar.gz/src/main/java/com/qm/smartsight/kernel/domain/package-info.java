/**
 * JPA domain objects.
 */
package com.qm.smartsight.kernel.domain;
