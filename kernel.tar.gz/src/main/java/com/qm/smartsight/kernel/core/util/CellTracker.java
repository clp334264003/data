package com.qm.smartsight.kernel.core.util;

import org.apache.hadoop.hbase.Cell;

/**
 * @author Woonduk Kang(emeroad)
 */
public interface CellTracker {

    void trace(Cell cell);

    void log();
}
