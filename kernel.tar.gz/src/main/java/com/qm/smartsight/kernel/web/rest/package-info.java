/**
 * Spring MVC REST controllers.
 */
package com.qm.smartsight.kernel.web.rest;
