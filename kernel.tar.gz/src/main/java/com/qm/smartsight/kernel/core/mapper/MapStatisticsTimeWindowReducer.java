package com.qm.smartsight.kernel.core.mapper;

import com.navercorp.pinpoint.common.hbase.RowReducer;
import com.qm.smartsight.kernel.core.applicationmap.rawdata.LinkDataMap;
import com.qm.smartsight.kernel.core.util.TimeWindow;

public class MapStatisticsTimeWindowReducer implements RowReducer<LinkDataMap> {

    private final LinkDataMap result;

    public MapStatisticsTimeWindowReducer(TimeWindow timeWindow) {
        result = new LinkDataMap(timeWindow);
    }

    @Override
    public LinkDataMap reduce(LinkDataMap map) throws Exception {
        result.addLinkDataMap(map);
        return result;
    }
}