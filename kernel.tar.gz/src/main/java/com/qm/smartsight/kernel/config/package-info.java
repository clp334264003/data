/**
 * Spring Framework configuration files.
 */
package com.qm.smartsight.kernel.config;
