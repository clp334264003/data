package com.qm.smartsight.kernel.core.filter.agent;

/**
 * @author emeroad
 */
public interface AgentFilter {
    boolean ACCEPT = true;
    boolean REJECT = false;

    boolean accept(String agentId);
}
