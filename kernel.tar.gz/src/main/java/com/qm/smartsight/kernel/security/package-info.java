/**
 * Spring Security configuration.
 */
package com.qm.smartsight.kernel.security;
