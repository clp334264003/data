import {join} from 'path';

import {SeedConfig} from './seed.config';
import { ExtendPackages } from './seed.config.interfaces';
const proxy = require('proxy-middleware');
/**
 * This class extends the basic seed configuration, allowing for project specific overrides. A few examples can be found
 * below.
 */
export class ProjectConfig extends SeedConfig {

    PROJECT_TASKS_DIR = join(process.cwd(), this.TOOLS_DIR, 'tasks', 'project');

    constructor() {
        super();
        // this.APP_TITLE = 'Put name of your app here';

        /* Enable typeless compiler runs (faster) between typed compiler runs. */
        // this.TYPED_COMPILE_INTERVAL = 5;

        // Add `NPM` third-party libraries to be injected/bundled.
        this.NPM_DEPENDENCIES = [
            ...this.NPM_DEPENDENCIES,
            // {src: 'jquery/dist/jquery.min.js', inject: 'libs'},
            // {src: 'lodash/lodash.min.js', inject: 'libs'},
            {src: 'hammerjs/hammer.js', inject: 'libs'},

            {src: 'jquery/dist/jquery.min.js', inject: 'libs'},
            {src: 'tether/dist/js/tether.js', inject: 'libs'},

            // {src: 'ng-jhipster/bundles/ng-jhipster.umd.js', inject: 'libs'},

            {src: 'daterangepicker/daterangepicker.js', inject: 'libs'},
            {src: 'echarts/dist/echarts.js', inject: 'libs'},
            {src: 'traceur/bin/traceur.js', inject: 'libs'},

            {src: 'webstomp-client/dist/webstomp.js', inject: 'libs'},
            {src: 'sockjs-client/dist/sockjs.js', inject: 'libs'},

            // {src: '@angular/material/core/theming/prebuilt/indigo-pink.css', inject: true},
            {src: 'font-awesome/css/font-awesome.min.css', inject: true},
            {src: 'bootstrap/dist/css/bootstrap.min.css', inject: true},
            // {src: 'bootstrap/dist/css/bootstrap-theme.css', inject: true},
            {src: 'daterangepicker/daterangepicker-bs3.css', inject: true},

        ];


        // Add `local` third-party libraries to be injected/bundled.
        this.APP_ASSETS = [
            ...this.APP_ASSETS,
            // {src: `${this.APP_SRC}/your-path-to-lib/libs/jquery-ui.js`, inject: true, vendor: false}
            // {src: `${this.CSS_SRC}/path-to-lib/test-lib.css`, inject: true, vendor: false},
        ];

        let additionalPackages: ExtendPackages[] = [
            {
                name: 'sockjs-client',
                path: 'node_modules/sockjs-client/dist/sockjs.js'
            },
            {
                name: 'webstomp-client',
                path: 'node_modules/webstomp-client/dist/webstomp.js'
            },
            // {
            //     name: '@angular/material',
            //     path: 'node_modules/@angular/material/bundles/material.umd.js',
            //     packageMeta: {
            //         main: 'index.js',
            //         defaultExtension: 'js'
            //     }
            // },
            {
                name: 'bootstrap',
                path: 'node_modules/bootstrap/dist/js/bootstrap.js'
            },
            {
                name: 'ng-jhipster',
                path: 'node_modules/ng-jhipster/bundles/index.js'
            },
            {
                name: 'moment',
                path: 'node_modules/moment/moment.js'
            },
            {
                name: 'moment-range',
                path: 'node_modules/moment-range/dist/moment-range.js'
            },
            // {
            //     name: 'angular2-jwt',
            //     path: 'node_modules/angular2-jwt/angular2-jwt.js'
            // },
            {
                name: 'ng2-webstorage',
                path: 'node_modules/ng2-webstorage/bundles/core.umd.js'
            },
            {
                name: 'angular2-select',
                path: 'node_modules/angular2-select/dist/angular2-select.js'
            },
            {
                name: '@ng-bootstrap/ng-bootstrap',
                path: 'node_modules/@ng-bootstrap/ng-bootstrap/bundles/ng-bootstrap.js'
            },
            {
                name: 'angular2-cookie',
                path: 'node_modules/angular2-cookie/bundles/angular2-cookie.js'
            },
            {
                name: 'angular2-infinite-scroll',
                path: 'node_modules/angular2-infinite-scroll/bundles/angular2-infinite-scroll.js',
                packageMeta: {
                    main: 'index.js',
                    defaultExtension: 'js'
                }
            }
        ];

        this.addPackagesBundles(additionalPackages);

        /* Add to or override NPM module configurations: */
        // this.mergeObject(this.PLUGIN_CONFIGS['browser-sync'], { ghostMode: false });
        this.PLUGIN_CONFIGS['browser-sync'] = {
            middleware: [
                proxy({
                    protocol: 'http:',
                    hostname: 'localhost',
                    port: 8080,
                    pathname: '/api',
                    route: '/api'
                }),
                require('connect-history-api-fallback')({index: `${this.APP_BASE}index.html`})
            ],
            port: this.PORT,
            startPath: this.APP_BASE,
            // open: argv['b'] ? false : true,
            injectChanges: false,
            server: {
                baseDir: `${this.DIST_DIR}/empty/`,
                routes: {
                    [`${this.APP_BASE}${this.APP_SRC}`]: this.APP_SRC,
                    [`${this.APP_BASE}${this.APP_DEST}`]: this.APP_DEST,
                    [`${this.APP_BASE}node_modules`]: 'node_modules',
                    [`${this.APP_BASE.replace(/\/$/, '')}`]: this.APP_DEST
                }
            }
        }
    }

}
