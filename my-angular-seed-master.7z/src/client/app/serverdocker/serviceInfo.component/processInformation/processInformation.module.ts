import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ProcessInformationComponent} from "./processInformation.component";
import {PartProcessInformationModule} from "../partProcessInformation/partProcessInformation.module";
import {PartProcessInformationService} from "../partProcessInformation/partProcessInformation.service";
import {SharedModule} from "../../../shared/shared.module";

@NgModule({
    imports: [
        CommonModule,
        PartProcessInformationModule,
        SharedModule

    ],
    declarations: [ProcessInformationComponent],
    exports: [ProcessInformationComponent],
    providers: [PartProcessInformationService]
})
export class ProcessInformationModule { }
