import {Component} from '@angular/core';
import {CookieService} from "angular2-cookie/services/cookies.service";
import {MemoryUsageService} from "./memoryUsage.service";
import {PartProcessInformationService} from "../partProcessInformation/partProcessInformation.service";
import {EchartsTheme} from "../../../shared/theme/echarts.theme";


declare var $: any;
declare var echarts: any;
var moment = require('moment');

@Component({
    moduleId: module.id,
    selector: 'sd-memoryUsage',
    templateUrl: 'memoryUsage.component.html',
    styleUrls: ['memoryUsage.component.css'],
})
export class MemoryUsageComponent {
    constructor(private _echartsTheme: EchartsTheme,
                private _cookieService: CookieService,
                private _memoryUsageService: MemoryUsageService,
                private _partProcessInformationService: PartProcessInformationService) {
        this._partProcessInformationService.showFlag = {
            showTop5CPU_Usage: false,
            showTop5CPU_TIME: false,
            showTop5VIRT: true,
        };
    }

    ngAfterViewInit() {
        this._memoryUsageService.mySwapmemoryusageChart = echarts.init(document.getElementById("mySwapmemoryusageChartBar"), this._echartsTheme.theme);
        this._memoryUsageService.mySwapmemoryusageChart.setOption(this._memoryUsageService.mySwapmemoryusageChartOption);

        // this._memoryUsageService.myPageschedulingChart = echarts.init(document.getElementById("myPageschedulingChartBar"), this._echartsTheme.theme);
        // this._memoryUsageService.myPageschedulingChart.setOption(this._memoryUsageService.myPageschedulingChartOption);

        this._memoryUsageService.myVirtualmemoryusageChart = echarts.init(document.getElementById("myVirtualmemoryusageChartBar"), this._echartsTheme.theme);
        this._memoryUsageService.myVirtualmemoryusageChart.setOption(this._memoryUsageService.myVirtualmemoryusageChartOption);

        this._memoryUsageService.myRealmemoryusageChart = echarts.init(document.getElementById("myRealmemoryusageChartBar"), this._echartsTheme.theme);
        this._memoryUsageService.myRealmemoryusageChart.setOption(this._memoryUsageService.myRealmemoryusageChartOption);

        let timeCookie: any = this._cookieService.getObject("timeCookie");
        let start: any;
        let end: any;
        if (timeCookie) {
            start = timeCookie.startTime;
            end = timeCookie.endTime;
        }
        else {
            start = moment().subtract(10, 'minutes');
            end = moment();
        }
        start = moment.unix(start).valueOf() / 1000;
        end = moment.unix(end).valueOf() / 1000;
        this._memoryUsageService.updatememoryUsageDatas(start, end);
    }
}
