import {Injectable}     from '@angular/core';
import {Http} from "@angular/http";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {PartProcessInformationService} from "../partProcessInformation/partProcessInformation.service";
import {MockCfg} from "../../../mock";

declare var $: any;
declare var echarts: any;
@Injectable()
export class MemoryUsageService {
    public server: any = {
        application: "",
        service: "",
        hostid: ""
    };
    public mySwapmemoryusageChart: any;
    // public myPageschedulingChart: any;
    public myVirtualmemoryusageChart: any;
    public myRealmemoryusageChart: any;

    constructor(
                private _cookieService: CookieService,
                private http: Http,
                private _partProcessInformationService: PartProcessInformationService) {
        this.server = this._cookieService.getObject("server");

    }

    // 请求 memoryUsage 页面数据
    updatememoryUsageDatas(from:number,to:number) {
        let serverInfomemoryUsageUrl: string = "";
        if (MockCfg.getMockFlag()) {
            serverInfomemoryUsageUrl = MockCfg.serverMockdataSourceURL() + "/api/memoryUsage?hostid=" + this.server.hostid + "from=" + from + "&to=" + to;
        }
        else {
            serverInfomemoryUsageUrl = MockCfg.dataSourceURL() + "/hosts/host/" + this.server.hostid + "/memoryUsage.pinpoint?from=" + from + "&to=" + to;
        }
        console.log("serverInfomemoryUsageUrl:" + serverInfomemoryUsageUrl);
        this.initmemoryUsageDatas();
        let that = this;
        this.http.get(serverInfomemoryUsageUrl).subscribe(res=> {
            let response = res.json();
            console.log("---updatememoryUsageDatas---");
            console.log(response);
            console.log("---updatememoryUsageDatas---");
            // 更新 交换内存使用情况
            let mySwapmemoryusageChartOptions = this.mySwapmemoryusageChart.getOption();
            mySwapmemoryusageChartOptions = this.mySwapmemoryusageChartOption;
            mySwapmemoryusageChartOptions.series[0].data = response["memoryUsage"]["swapmemoryusage"]["used"];
            mySwapmemoryusageChartOptions.series[1].data = response["memoryUsage"]["swapmemoryusage"]["idle"];
            mySwapmemoryusageChartOptions.series[2].data = response["memoryUsage"]["swapmemoryusage"]["total"];
            mySwapmemoryusageChartOptions.xAxis.data = response["memoryUsage"]["swapmemoryusage"]["time"];
            this.mySwapmemoryusageChart.setOption(mySwapmemoryusageChartOptions);
            this.mySwapmemoryusageChart.hideLoading();

            this.mySwapmemoryusageChart.on('click', function (params:any) {
                that.showDialog(params,that);

            });
            // 更新 页面调度
            // let myPageschedulingChartOptions = this.myPageschedulingChart.getOption();
            // myPageschedulingChartOptions = this.myPageschedulingChartOption;
            // myPageschedulingChartOptions.series[0].data = response["memoryUsage"]["pagescheduling"]["numberIn"];
            // myPageschedulingChartOptions.series[1].data = response["memoryUsage"]["pagescheduling"]["numberOut"];
            // myPageschedulingChartOptions.xAxis.data = response["memoryUsage"]["pagescheduling"]["time"];
            // this.myPageschedulingChart.hideLoading();
            // this.myPageschedulingChart.setOption(myPageschedulingChartOptions);
            // myPageschedulingChart.on('click', function (params) {
            //     $('#showDetails').modal('show');
            //     console.log(params);
            //     // null 给为时刻值;
            //     serverInfo_updateprocessInformationDatas(null);
            // });
            // 更新 虚拟内存使用情况
            let myVirtualmemoryusageChartOptions = this.myVirtualmemoryusageChart.getOption();
            myVirtualmemoryusageChartOptions = this.myVirtualmemoryusageChartOption;
            myVirtualmemoryusageChartOptions.series[0].data = response["memoryUsage"]["virtualmemoryusage"]["used"];
            myVirtualmemoryusageChartOptions.series[1].data = response["memoryUsage"]["virtualmemoryusage"]["idle"];
            myVirtualmemoryusageChartOptions.series[2].data = response["memoryUsage"]["virtualmemoryusage"]["total"];
            myVirtualmemoryusageChartOptions.xAxis.data = response["memoryUsage"]["virtualmemoryusage"]["time"];
            this.myVirtualmemoryusageChart.hideLoading();
            this.myVirtualmemoryusageChart.setOption(myVirtualmemoryusageChartOptions);
            this.myVirtualmemoryusageChart.on('click', function (params:any) {
                that.showDialog(params,that);
            });
            // 更新 实内存使用情况
            let myRealmemoryusageChartOptions = this.myRealmemoryusageChart.getOption();
            myRealmemoryusageChartOptions = this.myRealmemoryusageChartOption;
            myRealmemoryusageChartOptions.series[0].data = response["memoryUsage"]["realmemoryusage"]["idle"];
            // myRealmemoryusageChartOptions.series[1].data = response["memoryUsage"]["realmemoryusage"]["usedNetwork"];
            myRealmemoryusageChartOptions.series[1].data = response["memoryUsage"]["realmemoryusage"]["used"];
            myRealmemoryusageChartOptions.series[2].data = response["memoryUsage"]["realmemoryusage"]["total"];
            myRealmemoryusageChartOptions.xAxis.data = response["memoryUsage"]["realmemoryusage"]["time"];
            this.myRealmemoryusageChart.setOption(myRealmemoryusageChartOptions);
            this.myRealmemoryusageChart.hideLoading();
            this.myRealmemoryusageChart.on('click', function (params:any) {
                that.showDialog(params,that);
            });
        }, error=> {
            console.log(error);
        });
    }

    showDialog(params:any,that:any){
        let dateTimeStamp = params.name;
        let ndateTimeStamp:number = Date.parse(dateTimeStamp);
        console.log(ndateTimeStamp);
        $('#showMemoryUsageDetails').modal('show');
        that._partProcessInformationService.updateprocessInformationDatas(ndateTimeStamp);
    }
    // 请求前 初始化图表数据;
    initmemoryUsageDatas() {
        // 更新 交换内存使用情况
        // this.mySwapmemoryusageChart = echarts.init(document.getElementById("mySwapmemoryusageChartID"), this._echartsTheme.theme);
        let mySwapmemoryusageChartOptions = this.mySwapmemoryusageChart.getOption();
        mySwapmemoryusageChartOptions = this.mySwapmemoryusageChartOption;
        mySwapmemoryusageChartOptions.series[0].data = [];
        mySwapmemoryusageChartOptions.series[1].data = [];
        mySwapmemoryusageChartOptions.series[2].data = [];
        mySwapmemoryusageChartOptions.xAxis.data = [];
        this.mySwapmemoryusageChart.showLoading({
            text: "loading..."
        });
        this.mySwapmemoryusageChart.setOption(mySwapmemoryusageChartOptions);
        // 更新 页面调度
        // this.myPageschedulingChart = echarts.init(document.getElementById("myPageschedulingChartID"), bluetheme);
        // let myPageschedulingChartOptions = myPageschedulingChart.getOption();
        // myPageschedulingChartOptions = this.myPageschedulingChartOption;
        // myPageschedulingChartOptions.series[0].data = [];
        // myPageschedulingChartOptions.series[1].data = [];
        // myPageschedulingChartOptions.xAxis.data = [];
        // this.myPageschedulingChart.showLoading({
        //     text: "loading..."
        // });
        // this.myPageschedulingChart.setOption(myPageschedulingChartOptions);
        // 更新 虚拟内存使用情况
        // this.myVirtualmemoryusageChart = echarts.init(document.getElementById("myVirtualmemoryusageChartID"), this._echartsTheme.theme);
        let myVirtualmemoryusageChartOptions = this.myVirtualmemoryusageChart.getOption();
        myVirtualmemoryusageChartOptions = this.myVirtualmemoryusageChartOption;
        myVirtualmemoryusageChartOptions.series[0].data = [];
        myVirtualmemoryusageChartOptions.series[1].data = [];
        myVirtualmemoryusageChartOptions.series[2].data = [];
        myVirtualmemoryusageChartOptions.xAxis.data = [];
        this.myVirtualmemoryusageChart.showLoading({
            text: "loading..."
        });
        this.myVirtualmemoryusageChart.setOption(myVirtualmemoryusageChartOptions);
        // 更新 实内存使用情况
        // this.myRealmemoryusageChart = echarts.init(document.getElementById("myRealmemoryusageChartID"), this._echartsTheme.theme);
        let myRealmemoryusageChartOptions = this.myRealmemoryusageChart.getOption();
        myRealmemoryusageChartOptions = this.myRealmemoryusageChartOption;
        myRealmemoryusageChartOptions.series[0].data = [];
        // myRealmemoryusageChartOptions.series[1].data = response["memoryUsage"]["realmemoryusage"]["usedNetwork"];
        myRealmemoryusageChartOptions.series[1].data = [];
        myRealmemoryusageChartOptions.series[2].data = [];
        myRealmemoryusageChartOptions.xAxis.data = [];
        this.myRealmemoryusageChart.showLoading({
            text: "loading..."
        });
        this.myRealmemoryusageChart.setOption(myRealmemoryusageChartOptions);
        echarts.connect([this.mySwapmemoryusageChart, this.myVirtualmemoryusageChart, this.myRealmemoryusageChart]);
    }

// memoryUsage 页面数据
    mySwapmemoryusageChartOption = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            orient: 'horizontal',
            x: 'center', // 'center' | 'left' | {number},
            y: 'bottom', //
            padding: 0,    // [5, 10, 15, 20]
            itemGap: 20,
            data: ['used', 'available', 'total']
        },
        xAxis: {
            type: 'category',
            name: 'time',
            nameLocation: 'middle',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '25',
            boundaryGap: false,
            data: ['2017-2-7 8:55', '2017-2-7 8:56', '2017-2-7 8:57', '2017-2-7 8:58', '2017-2-7 8:59', '2017-2-7 9:00', '2017-2-7 9:01']
        },
        yAxis: {
            type: 'value',
            name: 'mb',
            nameLocation: 'end',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '15'
        },
        series: [
            {
                name: 'used',
                type: 'line',
                data: [0, 0, 0, 0, 0, 0, 0]
            },
            {
                name: 'available',
                type: 'line',
                data: [8000, 8000, 8000, 8000, 8000, 8000, 8000]
            },
            {
                name: 'total',
                type: 'line',
                stack: '总量',
                data: [8000, 8000, 8000, 8000, 8000, 8000, 8000]
            }
        ]
    };

    myPageschedulingChartOption = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            orient: 'horizontal',
            x: 'center', // 'center' | 'left' | {number},
            y: 'bottom', //
            padding: 0,    // [5, 10, 15, 20]
            itemGap: 20,
            data: ['每秒页面调进数', '每秒页面调出数']
        },
        xAxis: {
            type: 'category',
            name: 'time',
            nameLocation: 'middle',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '25',
            boundaryGap: false,
            data: ['2017-2-7 8:55', '2017-2-7 8:56', '2017-2-7 8:57', '2017-2-7 8:58', '2017-2-7 8:59', '2017-2-7 9:00', '2017-2-7 9:01', '2017-2-7 9:02', '2017-2-7 9:03', '2017-2-79:04', '2017-2-7 9:05', '2017-2-7 9:06', '2017-2-7 9:07', '2017-2-7 9:08']
        },
        yAxis: {
            type: 'value',
            name: '页面数',
            nameLocation: 'end',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '15'
        },
        series: [
            {
                name: '每秒页面调进数',
                type: 'line',
                data: [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000]
            },
            {
                name: '每秒页面调出数',
                type: 'line',
                data: [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000]
            }
        ]
    };

    myVirtualmemoryusageChartOption = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            orient: 'horizontal',
            x: 'center', // 'center' | 'left' | {number},
            y: 'bottom', //
            padding: 0,    // [5, 10, 15, 20]
            itemGap: 20,
            data: ['used', 'available', 'total']
        },
        xAxis: {
            type: 'category',
            name: 'time',
            nameLocation: 'middle',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '25',
            boundaryGap: false,
            data: ['2017-2-7 8:55', '2017-2-7 8:56', '2017-2-7 8:57', '2017-2-7 8:58', '2017-2-7 8:59', '2017-2-7 9:00', '2017-2-7 9:01']
        },
        yAxis: {
            type: 'value',
            name: 'mb',
            nameLocation: 'end',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '15'
        },
        series: [
            {
                name: 'used',
                type: 'line',
                data: [16000, 16000, 16000, 16000, 16000, 16000, 16000]
            },
            {
                name: 'available',
                type: 'line',
                data: [9000, 9000, 9000, 9000, 9000, 9000, 9000]
            },
            {
                name: 'total',
                type: 'line',
                stack: '总量',
                data: [25000, 25000, 25000, 25000, 25000, 25000, 25000]
            }
        ]
    };

    myRealmemoryusageChartOption = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            orient: 'horizontal',
            x: 'center', // 'center' | 'left' | {number},
            y: 'bottom', //
            padding: 0,    // [5, 10, 15, 20]
            itemGap: 20,  // data: ['available', 'usedNetwork', 'used', 'total']

            data: ['available', 'used', 'total']
        },
        xAxis: {
            type: 'category',
            name: 'time',
            nameLocation: 'middle',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '25',
            boundaryGap: false,
            data: ['2017-2-7 8:55', '2017-2-7 8:56', '2017-2-7 8:57', '2017-2-7 8:58', '2017-2-7 8:59', '2017-2-7 9:00', '2017-2-7 9:01']
        },
        yAxis: {
            type: 'value',
            name: 'mb',
            nameLocation: 'end',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '15'
        },
        series: [
            {
                name: 'available',
                type: 'line',
                data: [4000, 4000, 4000, 4000, 4000, 4000, 4000]
            },
            // {
            //     name: 'usedNetwork',
            //     type: 'line',
            //     data: [4000, 4000, 4000, 4000, 4000, 4000, 4000]
            // },
            {
                name: 'used',
                type: 'line',
                data: [4000, 4000, 4000, 4000, 4000, 4000, 4000]
            },
            {
                name: 'total',
                type: 'line',
                stack: '总量',
                data: [12000, 12000, 12000, 12000, 12000, 12000, 12000]
            }
        ]
    };
}

