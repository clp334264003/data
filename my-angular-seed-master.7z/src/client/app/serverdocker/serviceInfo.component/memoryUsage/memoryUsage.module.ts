import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MemoryUsageComponent} from "./memoryUsage.component";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {MemoryUsageService} from "./memoryUsage.service";
import {PartProcessInformationService} from "../partProcessInformation/partProcessInformation.service";
import {PartProcessInformationModule} from "../partProcessInformation/partProcessInformation.module";
import {SharedModule} from "../../../shared/shared.module";

@NgModule({
    imports: [
        CommonModule,
        PartProcessInformationModule,
        SharedModule
    ],
    declarations: [MemoryUsageComponent],
    exports: [MemoryUsageComponent],
    providers: [CookieService, MemoryUsageService,PartProcessInformationService]
})
export class MemoryUsageModule { }
