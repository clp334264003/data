import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ServiceInfoComponent} from "./serviceInfo.component";
import {ServiceInfoRoutingModule} from "./serviceInfo-routing.module";
import {OverviewModule} from "./overview/overview.module";
import {DiskModule} from "./disk/disk.module";
import {ProcessInformationModule} from "./processInformation/processInformation.module";
import {NetworkInterfaceModule} from "./networkInterface/networkInterface.module";
import {MemoryUsageModule} from "./memoryUsage/memoryUsage.module";
import {FileSystemModule} from "./fileSystem/fileSystem.module";
import {AggregateCPUUsageModule} from "./aggregateCPUUsage/aggregateCPUUsage.module";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {OverviewService} from "./overview/overview.service";
import {SharedModule} from "../../shared/shared.module";


@NgModule({
    imports: [
        CommonModule,
        ServiceInfoRoutingModule,
        OverviewModule,
        AggregateCPUUsageModule,
        DiskModule,
        FileSystemModule,
        MemoryUsageModule,
        NetworkInterfaceModule,
        ProcessInformationModule,
        SharedModule
    ],
    declarations: [ServiceInfoComponent],
    exports: [ServiceInfoComponent],
    providers: [ CookieService,OverviewService]
})
export class serviceInfoModule { }
