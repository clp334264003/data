import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import {ServiceInfoComponent} from "./serviceInfo.component";


@NgModule({
    imports: [
        RouterModule.forChild([

        ])
    ],
    exports: [RouterModule]
})
export class ServiceInfoRoutingModule { }
