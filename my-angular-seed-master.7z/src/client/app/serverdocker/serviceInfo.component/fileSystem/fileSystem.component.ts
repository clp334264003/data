import {Component} from '@angular/core';
import {FileSystemService} from "./fileSystem.service";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {EchartsTheme} from "../../../shared/theme/echarts.theme";

declare var $: any;
declare var echarts: any;
var moment = require('moment');

@Component({
    moduleId: module.id,
    selector: 'sd-fileSystem',
    templateUrl: 'fileSystem.component.html',
    styleUrls: ['fileSystem.component.css'],
})
export class FileSystemComponent {
    constructor(private _echartsTheme: EchartsTheme,
                private _cookieService: CookieService,
                private _fileSystemService: FileSystemService) {
    }

    ngAfterViewInit() {
        this._fileSystemService.myAggregatefilesystemusageChart = echarts.init(document.getElementById("myAggregatefilesystemusageChartBar"), this._echartsTheme.theme);
        this._fileSystemService.myAggregatefilesystemusageChart.setOption(this._fileSystemService.myAggregatefilesystemusageChartOption);

        this._fileSystemService.myAggregatefilesystemspaceusageChart = echarts.init(document.getElementById("myAggregatefilesystemspaceusageChartBar"), this._echartsTheme.theme);
        this._fileSystemService.myAggregatefilesystemspaceusageChart.setOption(this._fileSystemService.myAggregatefilesystemspaceusageChartOption);

        let timeCookie: any = this._cookieService.getObject("timeCookie");
        let start: any;
        let end: any;
        if (timeCookie) {
            start = timeCookie.startTime;
            end = timeCookie.endTime;
        }
        else {
            start = moment().subtract(10, 'minutes');
            end = moment();
        }
        start = moment.unix(start).valueOf() / 1000;
        end = moment.unix(end).valueOf() / 1000;
        this._fileSystemService.updatefileSystemDatas(start, end);
    }
}
