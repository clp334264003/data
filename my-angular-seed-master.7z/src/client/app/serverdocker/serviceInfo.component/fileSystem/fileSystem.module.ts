import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FileSystemComponent} from "./fileSystem.component";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {FileSystemService} from "./fileSystem.service";
import {SharedModule} from "../../../shared/shared.module";


@NgModule({
    imports: [
        CommonModule,
        SharedModule
    ],
    declarations: [FileSystemComponent],
    exports: [FileSystemComponent],
    providers: [CookieService, FileSystemService]
})
export class FileSystemModule { }
