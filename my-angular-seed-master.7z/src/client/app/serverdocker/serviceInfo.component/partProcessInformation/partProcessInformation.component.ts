import {Component} from '@angular/core';
import {CookieService} from "angular2-cookie/services/cookies.service";
import {PartProcessInformationService} from "./partProcessInformation.service";
declare var $: any;
@Component({
    moduleId: module.id,
    selector: 'sd-partProcessInformation',
    templateUrl: 'partProcessInformation.component.html',
    styleUrls: ['partProcessInformation.component.css'],
})
export class PartProcessInformationComponent {

    constructor(
        private _cookieService: CookieService,
        private _partProcessInformationService: PartProcessInformationService
    ) {
    }


}
