import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {PartProcessInformationComponent} from "./partProcessInformation.component";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {PartProcessInformationService} from "./partProcessInformation.service";
import {SharedModule} from "../../../shared/shared.module";


@NgModule({
    imports: [
        CommonModule,
        SharedModule
    ],
    declarations: [PartProcessInformationComponent],
    exports: [PartProcessInformationComponent],
    providers: [CookieService, PartProcessInformationService]
})
export class PartProcessInformationModule { }
