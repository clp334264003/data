import {Injectable}     from '@angular/core';
import {Http} from "@angular/http";
import {CookieService} from "angular2-cookie/services/cookies.service";


import * as moment from 'moment/moment';
import {MockCfg} from "../../../mock";


@Injectable()
export class PartProcessInformationService {
    public server: any = {
        application: "",
        service: "",
        hostid: ""
    };
    showFlag: any = {
        showTop5CPU_Usage: true,
        showTop5CPU_TIME: true,
        showTop5VIRT: true,
    }

    constructor(private _cookieService: CookieService,
                private http: Http) {
        this.server = this._cookieService.getObject("server");

    }


    // 请求 processInformation 页面数据
    topFPIOrderBycpuUsageDatas:any = [];
    topFPIOrderBytheCPUTimeUsedDatas:any = [];
    topFPIOrderByvirtualSizeDatas:any = [];
    isLoading = false;

    public updateprocessInformationDatas(to?: any) {

        let timeCookie: any = this._cookieService.getObject("timeCookie");
        let start: any;
        let end: any;
        if (timeCookie) {
            start = timeCookie.startTime;
            end = timeCookie.endTime;
        }
        else {
            start = moment().subtract(10, 'minutes');
            end = moment();
        }
        start = moment.unix(start).valueOf() / 1000;
        end = moment.unix(end).valueOf() / 1000;

        let serverInfoprocessInformationUrl: string = "";
        if (to == null) {
            if (MockCfg.getMockFlag()) {
                serverInfoprocessInformationUrl = MockCfg.serverMockdataSourceURL() + "/api/processInformation?hostid=" + this.server.hostid + "&from=" + start + "&to=" + end;
            }
            else {
                serverInfoprocessInformationUrl = MockCfg.dataSourceURL() + "/hosts/host/" + this.server.hostid + "/processInformation.pinpoint?from=" + start + "&to=" + end;
            }
            console.log("serverInfoprocessInformationUrl:" + serverInfoprocessInformationUrl);
        }
        else {
            if (MockCfg.getMockFlag()) {
                serverInfoprocessInformationUrl = MockCfg.serverMockdataSourceURL() + "/api/processInformation?hostid=" + this.server.hostid + "&to=" + to;
            }
            else {
                serverInfoprocessInformationUrl = MockCfg.dataSourceURL() + "/hosts/host/" + this.server.hostid + "/processInformation.pinpoint?to=" + to;
            }
        }
        console.log("serverInfoprocessInformationUrl:" + serverInfoprocessInformationUrl);
        this.isLoading = true;
        this.topFPIOrderBycpuUsageDatas = [];
        this.topFPIOrderBytheCPUTimeUsedDatas = [];
        this.topFPIOrderByvirtualSizeDatas = [];

        this.http.get(serverInfoprocessInformationUrl).subscribe(res=> {
            let response = res.json();
            console.log("---updateprocessInformationDatas---");
            console.log(response);
            console.log("---updateprocessInformationDatas---");
            this.topFPIOrderBycpuUsageDatas = response["processInformation"]["topFPIOrderBycpuUsageDatas"];
            this.topFPIOrderBytheCPUTimeUsedDatas = response["processInformation"]["topFPIOrderBytheCPUTimeUsedDatas"];
            this.topFPIOrderByvirtualSizeDatas = response["processInformation"]["topFPIOrderByvirtualSizeDatas"];
            this.isLoading = false;

        }, error=> {
            console.log(error);
            this.isLoading = false;
        });
    }
}

