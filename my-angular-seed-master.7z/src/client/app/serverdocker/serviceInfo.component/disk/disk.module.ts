import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {DiskComponent} from "./disk.component";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {DiskService} from "./disk.service";
import {SharedModule} from "../../../shared/shared.module";


@NgModule({
    imports: [
        CommonModule,
        SharedModule
    ],
    declarations: [DiskComponent],
    exports: [DiskComponent],
    providers: [CookieService, DiskService]
})
export class DiskModule { }
