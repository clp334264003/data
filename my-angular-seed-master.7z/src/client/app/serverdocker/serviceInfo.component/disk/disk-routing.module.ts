import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import {DiskComponent} from "./disk.component";


@NgModule({
    imports: [
        RouterModule.forChild([
            {
                path: '',
                component: DiskComponent,
            }
        ])
    ],
    exports: [RouterModule]
})
export class DiskRoutingModule { }
