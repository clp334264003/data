import {Component} from '@angular/core';
import {DiskService} from "./disk.service";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {EchartsTheme} from "../../../shared/theme/echarts.theme";

declare var $: any;
declare var echarts: any;
var moment = require('moment');
@Component({
    moduleId: module.id,
    selector: 'sd-disk',
    templateUrl: 'disk.component.html',
    styleUrls: ['disk.component.css'],
})
export class DiskComponent {
    constructor(
        private _echartsTheme: EchartsTheme,
        private _cookieService: CookieService,
        private _diskService: DiskService
    ) {
    }

    ngAfterViewInit() {
        this._diskService.myDiskoperationsChart = echarts.init(document.getElementById("myDiskoperationsChartBar"), this._echartsTheme.theme);
        this._diskService.myDiskoperationsChart.setOption(this._diskService.myDiskoperationsChartOption);
        this._diskService.myDiskusageChart = echarts.init(document.getElementById("myDiskusageChartBar"), this._echartsTheme.theme);
        this._diskService.myDiskusageChart.setOption(this._diskService.myDiskusageChartOption);
        let timeCookie: any = this._cookieService.getObject("timeCookie");
        let start: any;
        let end: any;
        if (timeCookie) {
            start = timeCookie.startTime;
            end = timeCookie.endTime;
        }
        else {
            start = moment().subtract(10, 'minutes');
            end = moment();
        }
        start = moment.unix(start).valueOf() / 1000;
        end = moment.unix(end).valueOf() / 1000;
        this._diskService.updatediskDatas(start, end);
    }
}
