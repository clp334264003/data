import {Injectable}     from '@angular/core';
import {Http} from "@angular/http";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {EchartsTheme} from "../../../shared/theme/echarts.theme";
import {MockCfg} from "../../../mock";


declare var $: any;
declare var echarts: any;
@Injectable(

)
export class OverviewService {
    public server: any = {
        application: "",
        service: "",
        hostid: ""
    };
    public myCpuChart: any;
    public mySmemoryChart: any;
    public myTopfivefileststemChart: any;
    public myTopfivediskChart: any;
    public myToptennetworkinterfaceChart: any;
    constructor(
        private _echartsTheme: EchartsTheme,
        private _cookieService: CookieService,
        private http: Http
    ) {
        this.server = this._cookieService.getObject("server");
    }
    // 请求前 初始化图表数据;
    initoverViewDatas() {
        // 更新 聚焦 CPU 使用率
        this.myCpuChart = echarts.init(document.getElementById("myCpuChartID"), this._echartsTheme.theme);
        this.myCpuChart.setOption(this.myCpuChartOption);
        let myCpuChartOptions = this.myCpuChart.getOption();
        myCpuChartOptions = this.myCpuChartOption;
        myCpuChartOptions.series[0].data = [];
        myCpuChartOptions.series[1].data = [];
        myCpuChartOptions.xAxis.data = [];
        this.myCpuChart.showLoading({
            text: "loading..."
        });
        this.myCpuChart.setOption(myCpuChartOptions);
        // 更新 内存使用情况
        this.mySmemoryChart = echarts.init(document.getElementById("mySmemoryChartID"), this._echartsTheme.theme);
        this.mySmemoryChart.setOption(this.mySmemoryChartOption);
        let mySmemoryChartOptions = this.mySmemoryChart.getOption();
        mySmemoryChartOptions = this.mySmemoryChartOption;
        mySmemoryChartOptions.series[0].data = [];
        mySmemoryChartOptions.series[1].data = [];
        this.mySmemoryChart.showLoading({
            text: "loading..."
        });
        this.mySmemoryChart.setOption(mySmemoryChartOptions);
        // 更新 排名前5位的文件系统
        this.myTopfivefileststemChart = echarts.init(document.getElementById("myTopfivefileststemID"), this._echartsTheme.theme);
        this.myTopfivefileststemChart.setOption(this.myTopfivefileststemOption);
        let myTopfivefileststemOptions = this.myTopfivefileststemChart.getOption();
        myTopfivefileststemOptions = this.myTopfivefileststemOption;
        myTopfivefileststemOptions.series[0].data = [];
        myTopfivefileststemOptions.series[1].data = [];
        myTopfivefileststemOptions.yAxis[0].data = [];
        this.myTopfivefileststemChart.showLoading({
            text: "loading..."
        });
        this.myTopfivefileststemChart.setOption(myTopfivefileststemOptions);
        // 更新 排名前5位的磁盘
        this.myTopfivediskChart = echarts.init(document.getElementById("myTopfivediskID"), this._echartsTheme.theme);
        this.myTopfivediskChart.setOption(this.myTopfivediskOption);
        let myTopfivediskOptions = this.myTopfivediskChart.getOption();
        myTopfivediskOptions = this.myTopfivediskOption;
        myTopfivediskOptions.series[0].data = [];
        myTopfivediskOptions.yAxis[0].data = [];
        this.myTopfivediskChart.showLoading({
            text: "loading..."
        });
        this.myTopfivediskChart.setOption(myTopfivediskOptions);
        // 更新 排名前10位的按传输包列出的网络接口
        this.myToptennetworkinterfaceChart = echarts.init(document.getElementById("myToptennetworkinterfaceID"), this._echartsTheme.theme);
        this.myToptennetworkinterfaceChart.setOption(this.myToptennetworkinterfaceOption);
        let myToptennetworkinterfaceOptions = this.myToptennetworkinterfaceChart.getOption();
        myToptennetworkinterfaceOptions = this.myToptennetworkinterfaceOption;
        myToptennetworkinterfaceOptions.series[0].data = [];
        myToptennetworkinterfaceOptions.yAxis[0].data = [];
        this.myToptennetworkinterfaceChart.showLoading({
            text: "loading..."
        });
        this.myToptennetworkinterfaceChart.setOption(myToptennetworkinterfaceOptions);
    }

    processInformation = {
        "numberOfActiveProcesses": 0,
        "numberOfZombieProcesses": 0,
        "numberOfThreads": 0,
        "theMaximumNumberOfProcessesAllowed": 0,
        "theMaximumNumberOfThreadsAllowed": 0
    }
    systemMessage = {
        "operatingSystem": "---",
        "theKernelVersion": "---",
        "FQDName": "---",
        "hostAddress": "---",
        "minutesOfTheSystem": "---",
        "systemUptime": "---",
    }
    theLogFile:any[];
    isoverViewLoading: boolean = false;
    isoverViewGetMsgFail: boolean = true;

    updateoverViewDatas(from: number, to: number) {
        let serverInfoOverViewUrl: string = "";
        if (MockCfg.getMockFlag()) {
            serverInfoOverViewUrl = MockCfg.serverMockdataSourceURL() + "/api/overview?hostid=" + this.server.hostid + "&from=" + from + "&to=" + to;
        }
        else {
            serverInfoOverViewUrl = MockCfg.dataSourceURL() + "/hosts/host/" + this.server.hostid + "/overview.pinpoint?from=" + from + "&to=" + to;
        }
        console.log("serverInfoOverViewUrl:" + serverInfoOverViewUrl);
        this.initoverViewDatas();
        this.isoverViewLoading = true;
        this.isoverViewGetMsgFail = false;
        this.http.get(serverInfoOverViewUrl).subscribe(res=> {
            let response = res.json();
            console.log("---updateoverViewDatas---");
            console.log(response);
            console.log("---updateoverViewDatas---");
            this.isoverViewLoading = false;
            this.isoverViewGetMsgFail = false;
            // 更新 聚焦 CPU 使用率
            var myCpuChartOptions = this.myCpuChart.getOption();
            myCpuChartOptions = this.myCpuChartOption;
            myCpuChartOptions.series[0].data = response["overview"]["aggregateCPUUsage"]["busyPercentage"];
            myCpuChartOptions.series[1].data = response["overview"]["aggregateCPUUsage"]["idlePercentage"];
            myCpuChartOptions.xAxis.data = response["overview"]["aggregateCPUUsage"]["time"];
            this.myCpuChart.setOption(myCpuChartOptions);
            this.myCpuChart.hideLoading();
            // 更新 内存使用情况
            var mySmemoryChartOptions = this.mySmemoryChart.getOption();
            mySmemoryChartOptions = this.mySmemoryChartOption;
            mySmemoryChartOptions.series[0].data = response["overview"]["smemory"]["percentageUsed"];
            mySmemoryChartOptions.series[1].data = response["overview"]["smemory"]["availablePercentage"];
            this.mySmemoryChart.hideLoading();
            this.mySmemoryChart.setOption(mySmemoryChartOptions);
            // 更新 排名前5位的文件系统
            var myTopfivefileststemOptions = this.myTopfivefileststemChart.getOption();
            myTopfivefileststemOptions = this.myTopfivefileststemOption;
            myTopfivefileststemOptions.series[0].data = response["overview"]["topfivefileststem"]["percentageUsed"];
            myTopfivefileststemOptions.series[1].data = response["overview"]["topfivefileststem"]["availablePercentage"];
            myTopfivefileststemOptions.yAxis[0].data = response["overview"]["topfivefileststem"]["installationPoint"];
            this.myTopfivefileststemChart.hideLoading();
            this.myTopfivefileststemChart.setOption(myTopfivefileststemOptions);
            // 更新 排名前5位的磁盘
            var myTopfivediskOptions = this.myTopfivediskChart.getOption();
            myTopfivediskOptions = this.myTopfivediskOption;
            myTopfivediskOptions.series[0].data = response["overview"]["topfivedisk"]["dataTransferredPerSecond"];
            myTopfivediskOptions.yAxis[0].data = response["overview"]["topfivedisk"]["disk"];
            this.myTopfivediskChart.hideLoading();
            this.myTopfivediskChart.setOption(myTopfivediskOptions);
            // 更新 排名前10位的按传输包列出的网络接口
            var myToptennetworkinterfaceOptions = this.myToptennetworkinterfaceChart.getOption();
            myToptennetworkinterfaceOptions = this.myToptennetworkinterfaceOption;
            myToptennetworkinterfaceOptions.series[0].data = response["overview"]["toptennetworkinterface"]["packetsTransferredPerSecond"];
            myToptennetworkinterfaceOptions.yAxis[0].data = response["overview"]["toptennetworkinterface"]["networkinterface"];
            this.myToptennetworkinterfaceChart.hideLoading();
            this.myToptennetworkinterfaceChart.setOption(myToptennetworkinterfaceOptions);
            this.processInformation = response["overview"]["processInformation"];
            this.theLogFile = response["overview"]["theLogFile"];
            this.systemMessage = response["overview"]["systemMessage"];
        }, error=> {
            console.log(error);
            this.isoverViewLoading = false;
            this.isoverViewGetMsgFail = true;
        });
    }

    // overView 页面数据
    public myCpuChartOption: any = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            orient: 'horizontal',
            x: 'center',
            y: 'bottom',
            padding: 0,
            itemGap: 20,
            data: ['%busy', '%idle']
        },
        xAxis: {
            type: 'category',
            name: 'time',
            nameLocation: 'middle',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '25',
            boundaryGap: false,
            data: ['', '', '', '', '', '', '', '']

        },
        yAxis: {
            type: 'value',
            name: '%',
            max: 100,
            nameLocation: 'end',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '15'
        },
        series: [
            {
                name: '%busy',
                type: 'line',
                data: [0, 0, 0, 0, 0, 0, 0, 0]
            },
            {
                name: '%idle',
                type: 'line',
                data: [0, 0, 0, 0, 0, 0, 0, 0]
            }
        ]
    };
    public mySmemoryChartOption: any = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            orient: 'horizontal',
            x: 'center',
            y: 'bottom',
            padding: 10,
            itemWidth: 15,
            data: ['%used', '%available']
        },
        calculable: true,
        xAxis: [
            {
                type: 'category',
                data: ['swap', 'virtual', 'physical']
            }
        ],
        yAxis: [
            {
                type: 'value',
                max: 100,
                name: '%',
                nameLocation: 'end',
                nameTextStyle: {
                    fontStyle: 'italic',
                    fontWeight: 'bolder',
                    fontSize: '16'
                },
                nameGap: '15'
            }
        ],
        series: [
            {
                name: '%used',
                type: 'bar',
                stack: 'sum',
                itemStyle: {
                    normal: {
                        color: '#734098',
                        barBorderRadius: 2,
                        label: {
                            show: true, position: 'insideTop'
                        }
                    }
                },
                data: [0, 0, 0]
            },
            {
                name: '%available',
                type: 'bar',
                stack: 'sum',
                barWidth: '35%',
                itemStyle: {
                    normal: {
                        color: '#FF7832',
                        barBorderRadius: 2,
                    }
                },
                data: [0, 0, 0]
            }
        ]
    };
    public myTopfivefileststemOption: any = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            orient: 'horizontal',
            x: 'center',
            y: 'bottom',
            padding: 10,
            itemWidth: 15,
            data: ['%used', '%available']
        },
        calculable: true,
        xAxis: [
            {
                type: 'value',
                max: '100',
            }
        ],
        yAxis: [
            {
                type: 'category',
                data: ['', '', '', '', ''],
                name: 'mount point',
                axisTick: {
                    interval: 0,

                },
                axisLabel: {
                    rotate: 30
                },
                nameLocation: 'end',
                nameTextStyle: {
                    fontStyle: 'italic',
                    fontWeight: 'bolder',
                    fontSize: '16'
                },
                nameGap: '15'
            }
        ],
        series: [
            {
                name: '%used',
                type: 'bar',
                stack: 'sum',
                itemStyle: {
                    normal: {
                        color: '#734098',
                        barBorderRadius: 2,
                        label: {
                            show: true, position: 'insideTop'
                        }
                    }
                },
                data: [0, 0, 0, 0, 0]
            },
            {
                name: '%available',
                type: 'bar',
                stack: 'sum',
                barWidth: '65%',
                itemStyle: {
                    normal: {
                        color: '#FF7832',
                        barBorderRadius: 2,
                    }
                },
                data: [0, 0, 0, 0, 0]
            }
        ]
    };
    public myTopfivediskOption: any = {
        tooltip: {
            trigger: 'axis'
        },
        calculable: true,
        xAxis: [
            {
                type: 'value',
                name: 'Blk/s',
                nameLocation: 'middle',
                nameTextStyle: {
                    fontStyle: 'italic',
                    fontWeight: 'bolder',
                    fontSize: '16'
                },
                nameGap: '25'
            }
        ],
        yAxis: [
            {
                type: 'category',
                data: ['', '', '', '', ''],
                name: 'disk',
                axisTick: {
                    interval: 0,
                },
                axisLabel: {
                    rotate: 30
                },
                nameLocation: 'end',
                nameTextStyle: {
                    fontStyle: 'italic',
                    fontWeight: 'bolder',
                    fontSize: '16'
                },
                nameGap: '15'
            }
        ],
        series: [
            {
                name: 'Blk/s',
                type: 'bar',
                stack: 'sum',
                itemStyle: {
                    normal: {
                        color: '#734098',
                        barBorderRadius: 2,
                        label: {
                            show: true, position: 'insideTop'
                        }
                    }
                },
                data: [0, 0, 0, 0, 0]
            }
        ]
    };
    public myToptennetworkinterfaceOption: any = {
        tooltip: {
            trigger: 'axis'
        },
        calculable: true,
        xAxis: [
            {
                type: 'value',
                boundaryGap: [0, 0.1],
                name: 'packets/s',
                nameLocation: 'middle',
                nameTextStyle: {
                    fontStyle: 'italic',
                    fontWeight: 'bolder',
                    fontSize: '16'
                },
                nameGap: '25'
            }
        ],
        yAxis: [
            {
                type: 'category',
                data: ['', '', '', '', '', '', '', '', '', ''],
                name: 'NIC',
                axisTick: {
                    interval: 0,
                },
                axisLabel: {
                    rotate: 30
                },
                nameLocation: 'end',
                nameTextStyle: {
                    fontStyle: 'italic',
                    fontWeight: 'bolder',
                    fontSize: '16'
                },
                nameGap: '15'
            }
        ],
        series: [
            {
                name: 'packets/s',
                type: 'bar',
                stack: 'sum',
                itemStyle: {
                    normal: {
                        color: '#734098',
                        barBorderRadius: 2
                    }
                },
                data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            }
        ]
    };

}

