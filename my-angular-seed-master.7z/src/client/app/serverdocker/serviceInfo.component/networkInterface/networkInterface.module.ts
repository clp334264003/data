import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {NetworkInterfaceComponent} from "./networkInterface.component";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {NetworkInterfaceService} from "./networkInterface.service";
import {SharedModule} from "../../../shared/shared.module";


@NgModule({
    imports: [
        CommonModule,
        SharedModule
    ],
    declarations: [NetworkInterfaceComponent],
    exports: [NetworkInterfaceComponent],
    providers: [CookieService, NetworkInterfaceService]
})
export class NetworkInterfaceModule { }
