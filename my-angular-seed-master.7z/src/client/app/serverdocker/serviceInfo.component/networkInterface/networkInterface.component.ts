import {Component} from '@angular/core';
import {NetworkInterfaceService} from "./networkInterface.service";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {EchartsTheme} from "../../../shared/theme/echarts.theme";

declare var $: any;
declare var echarts: any;
var moment = require('moment');

@Component({
    moduleId: module.id,
    selector: 'sd-networkInterface',
    templateUrl: 'networkInterface.component.html',
    styleUrls: ['networkInterface.component.css'],
})
export class NetworkInterfaceComponent {
    constructor(
        private _echartsTheme: EchartsTheme,
        private _cookieService: CookieService,
        private _networkInterfaceService: NetworkInterfaceService
    ) {
    }

    ngAfterViewInit() {
        this._networkInterfaceService.myAggregatenetworkinterfaceiorateChart = echarts.init(document.getElementById("myAggregatenetworkinterfaceiorateChartBar"), this._echartsTheme.theme);
        this._networkInterfaceService.myAggregatenetworkinterfaceiorateChart.setOption(this._networkInterfaceService.myAggregatenetworkinterfaceiorateChartOption);
        this._networkInterfaceService.myAggregatenetworkinterfaceerrorChart = echarts.init(document.getElementById("myAggregatenetworkinterfaceerrorChartBar"), this._echartsTheme.theme);
        this._networkInterfaceService.myAggregatenetworkinterfaceerrorChart.setOption(this._networkInterfaceService.myAggregatenetworkinterfaceerrorChartOption);
        let timeCookie: any = this._cookieService.getObject("timeCookie");
        let start: any;
        let end: any;
        if (timeCookie) {
            start = timeCookie.startTime;
            end = timeCookie.endTime;
        }
        else {
            start = moment().subtract(10, 'minutes');
            end = moment();
        }
        start = moment.unix(start).valueOf() / 1000;
        end = moment.unix(end).valueOf() / 1000;
        this._networkInterfaceService.updatenetworkInterfaceDatas(start, end);
    }
}
