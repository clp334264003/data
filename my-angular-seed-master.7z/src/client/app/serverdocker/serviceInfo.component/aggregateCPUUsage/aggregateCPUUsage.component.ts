import {Component} from '@angular/core';
import {CookieService} from "angular2-cookie/services/cookies.service";
import {AggregateCPUUsageService} from "./aggregateCPUUsage.service";

import {PartProcessInformationService} from "../partProcessInformation/partProcessInformation.service";
import {EchartsTheme} from "../../../shared/theme/echarts.theme";

declare var $: any;
declare var echarts: any;
var moment = require('moment');

@Component({
    moduleId: module.id,
    selector: 'sd-aggregateCPUUsage',
    templateUrl: 'aggregateCPUUsage.component.html',
    styleUrls: ['aggregateCPUUsage.component.css'],
})
export class AggregateCPUUsageComponent {
    constructor(private _echartsTheme: EchartsTheme,
                private _cookieService: CookieService,
                private _aggregateCPUUsageService: AggregateCPUUsageService,
                private _partProcessInformationService: PartProcessInformationService) {
        this._partProcessInformationService.showFlag = {
            showTop5CPU_Usage: true,
            showTop5CPU_TIME: true,
            showTop5VIRT: false,
        };
    }

    ngAfterViewInit() {
        this._aggregateCPUUsageService.myTopfivecpuusageChart = echarts.init(document.getElementById("myTopfivecpuusageChartBar"), this._echartsTheme.theme);
        this._aggregateCPUUsageService.myTopfivecpuusageChart.setOption(this._aggregateCPUUsageService.myTopfivecpuusageChartOption);
        this._aggregateCPUUsageService.myAggregatecpuusagedetailsChart = echarts.init(document.getElementById("myAggregatecpuusagedetailsChartBar"), this._echartsTheme.theme);
        this._aggregateCPUUsageService.myAggregatecpuusagedetailsChart.setOption(this._aggregateCPUUsageService.myAggregatecpuusagedetailsChartOption);
        let timeCookie: any = this._cookieService.getObject("timeCookie");
        let start: any;
        let end: any;
        if (timeCookie) {
            start = timeCookie.startTime;
            end = timeCookie.endTime;
        }
        else {
            start = moment().subtract(10, 'minutes');
            end = moment();
        }
        start = moment.unix(start).valueOf() / 1000;
        end = moment.unix(end).valueOf() / 1000;
        this._aggregateCPUUsageService.updateaggregateCPUUsageDatas(start, end);
    }
}
