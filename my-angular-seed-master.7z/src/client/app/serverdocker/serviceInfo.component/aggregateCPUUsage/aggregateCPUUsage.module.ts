import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AggregateCPUUsageComponent} from "./aggregateCPUUsage.component";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {AggregateCPUUsageService} from "./aggregateCPUUsage.service";
import {PartProcessInformationService} from "../partProcessInformation/partProcessInformation.service";
import {PartProcessInformationModule} from "../partProcessInformation/partProcessInformation.module";
import {SharedModule} from "../../../shared/shared.module";


@NgModule({
    imports: [
        CommonModule,
        PartProcessInformationModule,
        SharedModule
    ],
    declarations: [
        AggregateCPUUsageComponent
    ],
    exports: [AggregateCPUUsageComponent],
    providers: [CookieService, AggregateCPUUsageService,PartProcessInformationService]
})
export class AggregateCPUUsageModule {
}
