import {Injectable}     from '@angular/core';
import {Http} from "@angular/http";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {PartProcessInformationService} from "../partProcessInformation/partProcessInformation.service";
import {EchartsTheme} from "../../../shared/theme/echarts.theme";
import {MockCfg} from "../../../mock";

declare var $: any;
declare var echarts: any;
@Injectable()
export class AggregateCPUUsageService {
    public server: any = {
        application: "",
        service: "",
        hostid: ""
    };
    public myTopfivecpuusageChart: any;
    public myAggregatecpuusagedetailsChart: any;
    aggregateCPUUsage_cpu: any;

    constructor(private _echartsTheme: EchartsTheme,
                private _cookieService: CookieService,
                private http: Http,
                private _partProcessInformationService: PartProcessInformationService) {
        this.server = this._cookieService.getObject("server");
        this.aggregateCPUUsage_cpu = [];
    }

    // 请求前 初始化图表数据;
    initaggregateCPUUsageDatas() {

        // 更新 排名前5位的按使用率列出的CPU
        this.myTopfivecpuusageChart = echarts.init(document.getElementById("myTopfivecpuusageChartBar"), this._echartsTheme.theme);
        let myTopfivecpuusageChartOptions = this.myTopfivecpuusageChart.getOption();
        myTopfivecpuusageChartOptions = this.myTopfivecpuusageChartOption;
        myTopfivecpuusageChartOptions.series[0].data = [];
        myTopfivecpuusageChartOptions.series[1].data = [];
        myTopfivecpuusageChartOptions.series[2].data = [];
        myTopfivecpuusageChartOptions.series[3].data = [];
        myTopfivecpuusageChartOptions.xAxis.data = [];
        this.myTopfivecpuusageChart.showLoading({
            text: "loading..."
        });
        this.myTopfivecpuusageChart.setOption(myTopfivecpuusageChartOptions);

        // 更新 聚集CPU使用率详细信息
        this.myAggregatecpuusagedetailsChart = echarts.init(document.getElementById("myAggregatecpuusagedetailsChartBar"), this._echartsTheme.theme);
        let myAggregatecpuusagedetailsChartOptions = this.myAggregatecpuusagedetailsChart.getOption();
        myAggregatecpuusagedetailsChartOptions = this.myAggregatecpuusagedetailsChartOption;
        myAggregatecpuusagedetailsChartOptions.series[0].data = [];
        myAggregatecpuusagedetailsChartOptions.series[1].data = [];
        myAggregatecpuusagedetailsChartOptions.series[2].data = [];
        myAggregatecpuusagedetailsChartOptions.series[3].data = [];
        myAggregatecpuusagedetailsChartOptions.series[3].data = [];
        myAggregatecpuusagedetailsChartOptions.xAxis.data = [];
        this.myAggregatecpuusagedetailsChart.showLoading({
            text: "loading..."
        });
        this.myAggregatecpuusagedetailsChart.setOption(myAggregatecpuusagedetailsChartOptions);
    }


    isLoading: boolean;


    updateaggregateCPUUsageDatas(from: number, to: number) {
        let that = this;
        let serverInfoaggregateCPUUsageUrl: string = "";
        if (MockCfg.getMockFlag()) {
            serverInfoaggregateCPUUsageUrl = MockCfg.serverMockdataSourceURL() + "/api/aggregateCPUUsage?hostid=" + this.server.hostid + "from=" + from + "&to=" + to;
        }
        else {
            serverInfoaggregateCPUUsageUrl = MockCfg.dataSourceURL() + "/hosts/host/" + this.server.hostid + "/aggregateCPUUsage.pinpoint?from=" + from + "&to=" + to;
        }
        console.log("serverInfoaggregateCPUUsageUrl:" + serverInfoaggregateCPUUsageUrl);

        this.initaggregateCPUUsageDatas();
        this.isLoading = true;
        this.aggregateCPUUsage_cpu = [];

        this.http.get(serverInfoaggregateCPUUsageUrl).subscribe(res=> {
            let response = res.json();
            console.log("---updateaggregateCPUUsageDatas---");
            console.log(response);
            console.log("---updateaggregateCPUUsageDatas---");
            this.isLoading = false;
            this.aggregateCPUUsage_cpu = response["aggregateCPUUsage"]["cpu"];
            console.log(this.aggregateCPUUsage_cpu);
            // $scope.aggregateCPUUsage = response["aggregateCPUUsage"];

            // 更新 排名前5位的按使用率列出的CPU
            let myTopfivecpuusageChartOptions = this.myTopfivecpuusageChart.getOption();
            myTopfivecpuusageChartOptions = this.myTopfivecpuusageChartOption;
            myTopfivecpuusageChartOptions.series[0].data = response["aggregateCPUUsage"]["topfivecpuusage"]["percentageOfSystemTime"];
            myTopfivecpuusageChartOptions.series[1].data = response["aggregateCPUUsage"]["topfivecpuusage"]["percentOfUserTime"];
            myTopfivecpuusageChartOptions.series[2].data = response["aggregateCPUUsage"]["topfivecpuusage"]["waitForIOTimePercentage"];
            myTopfivecpuusageChartOptions.series[3].data = response["aggregateCPUUsage"]["topfivecpuusage"]["percentageOfIdleTime"];
            myTopfivecpuusageChartOptions.xAxis.data = response["aggregateCPUUsage"]["topfivecpuusage"]["cpuIdentification"];
            this.myTopfivecpuusageChart.hideLoading();
            this.myTopfivecpuusageChart.setOption(myTopfivecpuusageChartOptions);
            //
            // 更新 聚集CPU使用率详细信息
            let myAggregatecpuusagedetailsChartOptions = this.myAggregatecpuusagedetailsChart.getOption();
            myAggregatecpuusagedetailsChartOptions = this.myAggregatecpuusagedetailsChartOption;
            myAggregatecpuusagedetailsChartOptions.series[0].data = response["aggregateCPUUsage"]["aggregatecpuusagedetails"]["percentageOfUsers"];
            myAggregatecpuusagedetailsChartOptions.series[1].data = response["aggregateCPUUsage"]["aggregatecpuusagedetails"]["userNicePercentage"];
            myAggregatecpuusagedetailsChartOptions.series[2].data = response["aggregateCPUUsage"]["aggregatecpuusagedetails"]["percentageOfSystem"];
            myAggregatecpuusagedetailsChartOptions.series[3].data = response["aggregateCPUUsage"]["aggregatecpuusagedetails"]["waitForIOPercentage"];
            myAggregatecpuusagedetailsChartOptions.series[4].data = response["aggregateCPUUsage"]["aggregatecpuusagedetails"]["userToSystemPercentage"];
            myAggregatecpuusagedetailsChartOptions.xAxis.data = response["aggregateCPUUsage"]["aggregatecpuusagedetails"]["time"];
            this.myAggregatecpuusagedetailsChart.hideLoading();
            this.myAggregatecpuusagedetailsChart.setOption(myAggregatecpuusagedetailsChartOptions);
            this.myAggregatecpuusagedetailsChart.on('click', function (params:any) {
                let dateTimeStamp = params.name;
                let ndateTimeStamp: number = Date.parse(dateTimeStamp);
                console.log(ndateTimeStamp);
                $('#showAggregateCPUUsageDetails').modal('show');
                that._partProcessInformationService.updateprocessInformationDatas(ndateTimeStamp);
            });
        }, error=> {
            console.log(error);
            this.isLoading = false;
        });
    }

    showDialog(params: any, that: any) {
        let dateTimeStamp = params.name;
        let ndateTimeStamp: number = Date.parse(dateTimeStamp);
        console.log(ndateTimeStamp);
        $('#showMemoryUsageDetails').modal('show');
        that._partProcessInformationService.updateprocessInformationDatas(ndateTimeStamp);
    }

// aggregateCPUUsage 页面数据
    myTopfivecpuusageChartOption = {
        tooltip: {
            trigger: 'axis',
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
        },
        legend: {
            data: ['system%', 'user%', 'iowait%', 'idle%'],
            orient: 'horizontal',
            x: 'center',
            y: 'bottom',
            padding: 0,
            itemWidth: 20,

        },
        xAxis: {
            type: 'category',
            name: 'CPU id',
            nameLocation: 'middle',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '25',
            data: ['', '', '', '', '']

        },
        yAxis: {
            type: 'value',
            max: 100,
            name: '%',
            nameLocation: 'end',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '15'
        },
        series: [
            {
                name: 'system%',
                type: 'bar',
                data: [0, 0, 0, 0, 0]
            },
            {
                name: 'user%',
                type: 'bar',
                data: [0, 0, 0, 0, 0]
            },
            {
                name: 'iowait%',
                type: 'bar',
                data: [0, 0, 0, 0, 0]
            },
            {
                name: 'idle%',
                type: 'bar',
                data: [0, 0, 0, 0, 0]
            }
        ]
    };

    myAggregatecpuusagedetailsChartOption = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            orient: 'horizontal',
            x: 'center', // 'center' | 'left' | {number},
            y: 'bottom', //
            padding: 0,    // [5, 10, 15, 20]
            itemGap: 20,
            data: ['user%', 'nice%', 'system%', 'iowait%', 'user/system%']
        },
        xAxis: {
            type: 'category',
            name: 'time',
            nameLocation: 'middle',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '25',
            boundaryGap: false,
            data: ['', '', '', '', '', '', '']
        },
        yAxis: {
            type: 'value',
            name: '%',
            // max: 100,
            nameLocation: 'end',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '15'
        },
        series: [
            {
                name: 'user%',
                type: 'line',
                data: [0, 0, 0, 0, 0, 0, 0]
            },
            {
                name: 'nice%',
                type: 'line',
                data: [0, 0, 0, 0, 0, 0, 0]
            },
            {
                name: 'system%',
                type: 'line',
                data: [0, 0, 0, 0, 0, 0, 0]
            },
            {
                name: 'iowait%',
                type: 'line',
                data: [0, 0, 0, 0, 0, 0, 0]
            },
            {
                name: 'user/system%',
                type: 'line',
                data: [0, 0, 0, 0, 0, 0, 0]
            }
        ]
    };

}

