import {Component} from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'sd-serverdocker',
    templateUrl: 'serverdocker.component.html',
    styleUrls: ['serverdocker.component.css'],
})
export class ServerdockerComponent {
    constructor() {
    }
}
