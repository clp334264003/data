import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import {ServerdockerComponent} from "./serverdocker.component";
import {ServicelistComponent} from "./servicelist.component/servicelist.component";
import {ServiceInfoComponent} from "./serviceInfo.component/serviceInfo.component";
import {OverviewComponent} from "./serviceInfo.component/overview/overview.component";
import {DiskComponent} from "./serviceInfo.component/disk/disk.component";
import {AggregateCPUUsageComponent} from "./serviceInfo.component/aggregateCPUUsage/aggregateCPUUsage.component";
import {MemoryUsageComponent} from "./serviceInfo.component/memoryUsage/memoryUsage.component";
import {FileSystemComponent} from "./serviceInfo.component/fileSystem/fileSystem.component";
import {NetworkInterfaceComponent} from "./serviceInfo.component/networkInterface/networkInterface.component";
import {ProcessInformationComponent} from "./serviceInfo.component/processInformation/processInformation.component";

@NgModule({
    imports: [
        RouterModule.forChild([
            {
                path: 'serverdocker',
                component: ServerdockerComponent,
                children: [
                    {
                        path: 'servicelist',
                        component: ServicelistComponent
                    },
                    {
                        path: 'serviceInfo',
                        component: ServiceInfoComponent,
                        children: [
                            {
                                path: 'overview',
                                component: OverviewComponent
                            },
                            {
                                path: 'aggregateCPUUsage',
                                component: AggregateCPUUsageComponent
                            },
                            {
                                path: 'memoryUsage',
                                component: MemoryUsageComponent
                            },
                            {
                                path: 'fileSystem',
                                component: FileSystemComponent
                            },
                            {
                                path: 'disk',
                                component: DiskComponent
                            },
                            {
                                path: 'networkInterface',
                                component: NetworkInterfaceComponent
                            },
                            {
                                path: 'processInformation',
                                component: ProcessInformationComponent
                            }
                        ]
                    }
                ]
            },
        ])
    ],
    exports: [RouterModule]
})
export class ServerdockerRoutingModule { }