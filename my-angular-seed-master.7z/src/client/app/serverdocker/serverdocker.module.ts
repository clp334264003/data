import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ServerdockerComponent} from "./serverdocker.component";
import {ServicelistModule} from "./servicelist.component/servicelist.module";
import {serviceInfoModule} from "./serviceInfo.component/serviceInfo.module";
import {SharedModule} from "../shared/shared.module";

@NgModule({
    imports: [
        CommonModule,
        ServicelistModule,
        serviceInfoModule,
        SharedModule
    ],
    declarations: [ServerdockerComponent],
    exports: [ServerdockerComponent]
})
export class ServerdockerModule { }
