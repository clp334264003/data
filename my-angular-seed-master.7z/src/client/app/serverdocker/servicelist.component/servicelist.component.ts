import {Component} from '@angular/core';
import {Http} from "@angular/http";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {Router} from "@angular/router";
import {MockCfg} from "../../mock";

var moment = require('moment');

declare var $: any;
@Component({
    moduleId: module.id,
    selector: 'sd-servicelist',
    templateUrl: 'servicelist.component.html',
    styleUrls: ['servicelist.component.css'],
    providers: [CookieService]
})
export class ServicelistComponent {
    isLoading: boolean;
    displayServers: any;
    from: any;
    to: any;

    constructor(private _cookieService: CookieService,
                private router: Router,
                private http: Http) {
        this.displayServers = [];
        this.isLoading = false;

        let timeCookie: any = this._cookieService.getObject("timeCookie");
        let start: any;
        let end: any;
        if (timeCookie) {
            start = timeCookie.startTime;
            end = timeCookie.endTime;
        }
        else {
            start = moment().subtract(10, 'minutes');
            end = moment();
        }
        start = moment.unix(start).valueOf() / 1000;
        end = moment.unix(end).valueOf() / 1000;
        this.getServiceList(start, end);
    }

    getServiceList(from: number, to: number) {
        this.isLoading = true;
        this.http.get(MockCfg.base8084Url + MockCfg.serverstatsUrl + "?from=" + from + "&to=" + to).subscribe(res=> {

            console.log(res);
            this.displayServers = res.json().servers;
            console.log(this.displayServers);
            this.isLoading = false;
        }, error=> {
            this.isLoading = false;
            console.log(error);
        });
    }

    searchByTime(data: any) {
        let start = moment.unix(data.startTime).valueOf() / 1000;
        let end = moment.unix(data.endTime).valueOf() / 1000;
        this.getServiceList(start, end);
    }

    goToServiceInfo(application: string, service: string, hostid: string) {
        let server:any = {
            application: application,
            service: service,
            hostid: hostid
        };
        server = this._cookieService.putObject("server", server);
        this.router.navigate(['serverdocker/serviceInfo/overview']);
    }
}
