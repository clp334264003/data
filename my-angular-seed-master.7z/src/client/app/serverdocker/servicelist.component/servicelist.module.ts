import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ServicelistComponent} from "./servicelist.component";
import {ServicelistRoutingModule} from "./servicelist-routing.module";
import {SharedModule} from "../../shared/shared.module";


@NgModule({
    imports: [
        CommonModule,
        ServicelistRoutingModule,
        SharedModule
    ],
    declarations: [
        ServicelistComponent,

    ],
    exports: [ServicelistComponent]
})
export class ServicelistModule { }
