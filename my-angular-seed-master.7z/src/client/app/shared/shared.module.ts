import {NgModule, ModuleWithProviders, CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';
import {VariableService} from "./service/variable.service";
import {LoadingTableComponent} from "./table/loading-table.component";
import {EmptyTableComponent} from "./table/empty-table.component";
import {Principal} from "./auth/principal.service";
import {AccountService} from "./auth/account.service";
import {AuthServerProvider} from "./auth/auth-jwt.service";
import {LocalStorageService, SessionStorageService} from "ng2-webstorage";
import {JhiLoginModalComponent} from "./login/login.component";
import {LoginService} from "./login/login.service";
import {LoginModalService} from "./login/login-modal.service";
import {StateStorageService} from "./auth/state-storage.service";
import {EventManager} from "ng-jhipster";
import {NgbModule} from "@ng-bootstrap/ng-bootstrap";
import {SocialService} from "./social/social.service";
import {JhiSocialComponent} from "./social/social.component";
import {CSRFService} from "./auth/csrf.service";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {HttpModule} from "@angular/http";
import {HasAnyAuthorityDirective} from "./auth/has-any-authority.directive";
import {HighlightDirective} from "./auth/highlight.directive";
import {NavbarComponent} from "../layouts/navbar/navbar.component";
import {PageRibbonComponent} from "../layouts/profiles/page-ribbon.component";
import {ProfileService} from "../layouts/profiles/profile.service";
import {FooterComponent} from "../layouts/footer/footer.component";
import {searchWithTimeModule} from "./searchWithTime/searchWithTime.module";
import {EchartsTheme} from "./theme/echarts.theme";
import {SelectModule} from "angular2-select";
// import {JhiTrackerService} from "./tracker/tracker.service";




/**
 * Do not specify providers for modules that might be imported by a lazy loaded module.
 */

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        FormsModule,
        SelectModule,
        searchWithTimeModule,
        NgbModule.forRoot(),
        // NgJhipsterModule i18n 运行失败
        // NgJhipsterModule.forRoot({
        // }),
        // InfiniteScrollModule
    ],
    declarations: [
        FooterComponent,
        NavbarComponent,
        JhiSocialComponent,
        PageRibbonComponent,
        JhiLoginModalComponent,
        LoadingTableComponent,
        EmptyTableComponent,
        HasAnyAuthorityDirective,
        HighlightDirective

    ],
    entryComponents: [JhiLoginModalComponent],
    exports: [
        FormsModule,
        HttpModule,
        CommonModule,
        NgbModule,
        RouterModule,
        SelectModule,
        JhiLoginModalComponent,
        FooterComponent,
        NavbarComponent,
        JhiSocialComponent,
        PageRibbonComponent,
        LoadingTableComponent,
        EmptyTableComponent,
        NgbModule,
        searchWithTimeModule,
        HasAnyAuthorityDirective,
        HighlightDirective

    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SharedModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: SharedModule,
            providers: [
                EchartsTheme,
                EventManager,
                VariableService,
                LoginService,
                LoginModalService,
                Principal,
                AccountService,
                AuthServerProvider,
                LocalStorageService,
                StateStorageService,
                SessionStorageService,
                ProfileService,
                SocialService,
                CSRFService,
                CookieService,
                // JhiTrackerService
            ]
        };
    }
}
