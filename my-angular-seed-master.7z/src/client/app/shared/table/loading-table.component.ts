import {Component, Input} from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'loading-table',
    templateUrl: 'loading-table.component.html',
    styleUrls: ['loading-table.component.css']
})
export class LoadingTableComponent {
}