import {Input, Output, EventEmitter, ViewChild, ElementRef, AfterViewInit, Component, OnInit} from '@angular/core';

import {CookieService} from "angular2-cookie/services/cookies.service";
import {DateFormat} from "../common/dateFormat";

declare var $: any;
var moment = require('moment');

@Component({
    moduleId: module.id,
    selector: 'daterangepicker',
    template: `
        <div #daterangepicker data-toggle="tooltip" data-placement="bottom" title="Default Tooltip" style="border:1px solid blue;padding: 5px 5px">
            <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;<span>{{showTime}}</span><b class="caret"></b>
        </div>`,
    providers: [ CookieService,DateFormat ]
})
export class DaterangepickerComponent implements OnInit {
    @Input() options: any = {};
    @Output() selected = new EventEmitter();
    @ViewChild('daterangepicker') div: ElementRef;
    private showTime:String;
    constructor(
        private _cookieService:CookieService,
        private _dateFormat:DateFormat
    ) {}
    public ngOnInit(): void {
        $(this.div.nativeElement).daterangepicker(this.options, this.callback.bind(this));
        // TODO 需要改为先读取cookie，若为空，则设置默认值
        let timeCookie:any = this._cookieService.getObject("timeCookie");
        let start:any;
        let end:any;
        if(timeCookie){
            start = timeCookie.startTime;
            end  = timeCookie.endTime;
        }
        else {
            start = moment().subtract(10,'minutes');
            end =  moment();
        }

        this.showTime = this._dateFormat.IsoLocalTime(new Date(start)) + ' - '
            +  this._dateFormat.IsoLocalTime(new Date(end));
        this.options.startDate = start;
        this.options.endDate =  end;
    }

    private callback(start: any, end: any) {
        let obj = {
            start: start,
            end: end
        };
        this.selected.emit(obj);
        this.showTime = this._dateFormat.IsoLocalTime(new Date(start)) + ' - '
            +  this._dateFormat.IsoLocalTime(new Date(end));
    }
}