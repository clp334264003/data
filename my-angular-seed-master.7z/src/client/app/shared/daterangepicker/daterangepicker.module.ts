import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DaterangepickerComponent } from './daterangepicker.component';

@NgModule({
    imports: [ CommonModule ],
    declarations: [ DaterangepickerComponent ],
    exports: [ DaterangepickerComponent ],
    providers: []
})
export class DaterangepickerModule {

}


// private options: Object = {
//     'showDropdowns': true,
//     'showWeekNumbers': true,
//     'timePicker': true,
//     'timePicker12Hour': false,
//     'alwaysShowCalendars': true,
//     'minDate': '06/01/2014',
//     'buttonClasses': 'btn btn-outline-success',
//     'applyClass': 'btn btn-outline-primary',
//     'cancelClass': 'btn btn-outline-warning'
// };
//
// private selectedDate(value: any) {
//     console.log(value);
// }


// <div class="dataRangePicker">
//     <daterangepicker [options]="options" (selected)="selectedDate($event)" ></daterangepicker>
//     </div>

// .dataRangePicker {
//     width: 320px;
//     float: right;
//     margin: -35px 40px 10px 20px;
//     color: #4d5761;
// }