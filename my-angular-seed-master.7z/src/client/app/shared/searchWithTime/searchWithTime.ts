import {Component, OnInit, EventEmitter, Output} from '@angular/core';

import { CookieService } from 'angular2-cookie/services/cookies.service';

// import * as moment from 'moment/moment';
var moment = require('moment');

/**
 * This class represents the lazy loaded HomeComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-searchWithTime',
    templateUrl: 'searchWithTime.html',
    styleUrls: ['searchWithTime.css'],
    providers: [ CookieService ],
})
export class searchWithTimeComponent implements OnInit {
    timestate:boolean;
    timerange:string;
    startTime:any;
    endTime:any;


    @Output('searchbytime') searchbytime = new EventEmitter<any>();

    constructor(
        private _cookieService:CookieService
    ) {}

    ngOnInit() {

        let timeCookie:any = this._cookieService.getObject("timeCookie");
        if(timeCookie){
            this.timestate = timeCookie.timestate;
            this.timerange = timeCookie.timesign;
            this.startTime = timeCookie.startTime;
            this.endTime = timeCookie.endTime;
            this.timerange = timeCookie.timesign;
        }
        else {
            this.startTime = '';
            this.endTime = '';
            this.timerange = '10m';
            this.timestate = true;
        }

    }
    search(timesign?:string) {
        if (timesign === '10m') {
            this.startTime = moment().subtract(10,'minutes');
            this.endTime = moment();
        }
        else if (timesign === '30m') {
            this.startTime = moment().subtract(30,'minutes');
            this.endTime = moment();
        }
        else if (timesign === '2h') {
            this.startTime = moment().subtract(2,'hours');
            this.endTime = moment();
        }
        else if (timesign === 'today') {
            this.startTime = moment().startOf('day');
            this.endTime = moment();
        }
        else if (timesign === 'yesterday') {
            this.startTime = moment().subtract(1,'days').startOf('day');
            this.endTime = moment().subtract(1,'days').endOf('day');
        }
        else if (timesign === '1week') {
            this.startTime = moment().subtract(6,'days');
            this.endTime =  moment();
        }
        else if (timesign === '30days') {
            this.startTime = moment().subtract(29,'days');
            this.endTime = moment();
        }
        this.startTime = moment.unix(this.startTime).valueOf()/1000;
        this.endTime = moment.unix(this.endTime).valueOf()/1000;
        let time:any = {
            timestate:this.timestate,
            timesign:timesign,
            startTime:this.startTime,
            endTime:this.endTime
        };
        this._cookieService.putObject("timeCookie",time);
        this.searchbytime.emit({startTime: this.startTime, endTime: this.endTime});

    }

    switchTimestate() {
        this.timestate = !this.timestate;
    }
    private options: any = {
        dateLimit : {
            days : 150
        },
        showDropdowns: true,
        showWeekNumbers: false,
        timePicker: true,
        timePickerIncrement : 1,
        timePicker12Hour: false,
        alwaysShowCalendars: true,
        buttonClasses : [ 'btn btn-default' ],
        applyClass : 'btn btn-sm btn-primary blue',
        cancelClass : 'btn btn-sm',
        ranges : {
            '10 Minutes': [moment().subtract(10,'minutes'), moment()],
            '30 Minutes': [moment().subtract(30,'minutes'), moment()],
            '2 Hours': [moment().subtract(2,'hours'), moment()],
            'Today': [moment().startOf('day'), moment()],
            'Yesterday': [moment().subtract(1,'days').startOf('day'), moment().subtract(1,'days').endOf('day')],
            '1 Week': [moment().subtract(6,'days'), moment()],
            '30 Days': [moment().subtract(29,'days'), moment()]
        },
        opens : 'left',
        format : 'YYYY-MM-DD HH:mm:ss',
        separator : ' to '
    };

    private selectedDate(value: any) {
        this.startTime = moment.unix(value.startTime).valueOf()/1000;
        this.endTime = moment.unix(value.endTime).valueOf()/1000;
        let time:any = {
            timestate:this.timestate,
            timesign:"customize",
            startTime:this.startTime,
            endTime:this.endTime
        };
        this._cookieService.putObject("timeCookie",time);
        this.searchbytime.emit({startTime: this.startTime, endTime: this.endTime});
    }

}
