import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {SharedModule} from "../shared.module";
import {searchWithTimeComponent} from "./searchWithTime";
import {DaterangepickerModule} from "../daterangepicker/daterangepicker.module";


@NgModule({
    imports: [
        CommonModule,
        DaterangepickerModule
    ],
    declarations: [searchWithTimeComponent],
    exports: [searchWithTimeComponent],
    providers: []
})
export class searchWithTimeModule {
}
