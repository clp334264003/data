import {Injectable} from '@angular/core';
@Injectable()

export class DateFormat {


    IsoLocalTime(inputIntTime: any) {
        if (!inputIntTime) {
            return null;
        }
        if (!isNaN(inputIntTime)) {
            inputIntTime = inputIntTime;
        } else {
            inputIntTime = Date.parse(inputIntTime);
        }
        let localTime: string = '';
        let offset: number = (new Date()).getTimezoneOffset();
        localTime = (new Date(inputIntTime - offset * 60000)).toISOString();
        localTime = localTime.substr(0, localTime.lastIndexOf('Z'));
        localTime = localTime.replace('T', ' ');
        localTime = localTime.substr(0, localTime.length-4);
        return localTime;
    }

    LocalIsoTime(inputIntTime: any) {
        if (!inputIntTime) {
            return null;
        }
        inputIntTime = Date.parse(inputIntTime);
        let IsoTime: string = '';
        //let offset: number = (new Date()).getTimezoneOffset();
        IsoTime = (new Date(inputIntTime)).toISOString();
        return IsoTime;
    }

    formatDate(inputIntTime: any) {
        let year = inputIntTime.getYear();
        let month = inputIntTime.getMonth() + 1;
        let date = inputIntTime.getDate();
        let hour = inputIntTime.getHours();
        let minute = inputIntTime.getMinutes();
        let second = inputIntTime.getSeconds();
        let show = year + "-" + month + "-" + date + "   " + hour + ":" + minute + ":" + second;
        console.log(show);
        return show;
    };
}
