import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import {NavbarComponent} from "./layouts/navbar/navbar.component";
import {HomeComponent} from "./home/home.component";
import {ApplicationsComponent} from "./applications/applications.component";
import {ServerdockerComponent} from "./serverdocker/serverdocker.component";
import {AnalyticsComponent} from "./analytics/analytics.component";
import {MiddlewaresComponent} from "./middlewares/middlewares.component";
import {PoliciesComponent} from "./policies/policies.component";
import {PolicyComponent} from "./policies/policy/policy.component";
import {ServicelistComponent} from "./serverdocker/servicelist.component/servicelist.component";
import {ServiceInfoComponent} from "./serverdocker/serviceInfo.component/serviceInfo.component";
import {OverviewComponent} from "./serverdocker/serviceInfo.component/overview/overview.component";
import {AggregateCPUUsageComponent} from "./serverdocker/serviceInfo.component/aggregateCPUUsage/aggregateCPUUsage.component";
import {MemoryUsageComponent} from "./serverdocker/serviceInfo.component/memoryUsage/memoryUsage.component";
import {FileSystemComponent} from "./serverdocker/serviceInfo.component/fileSystem/fileSystem.component";
import {DiskComponent} from "./serverdocker/serviceInfo.component/disk/disk.component";
import {NetworkInterfaceComponent} from "./serverdocker/serviceInfo.component/networkInterface/networkInterface.component";
import {ProcessInformationComponent} from "./serverdocker/serviceInfo.component/processInformation/processInformation.component";
import {NFVTraceComponent} from "./nfvTrace/nfvTrace.component";


@NgModule({
  imports: [
    RouterModule.forRoot([
      /* define app module routes here, e.g., to lazily load a module
         (do not place feature module routes here, use an own -routing.module.ts in the feature instead)
       */
        {path: '', component: NavbarComponent, outlet: 'navbar'},
        {
            path: '',
            redirectTo: 'home',
            pathMatch: 'full'
        },
        {
            path: 'home',
            component: HomeComponent,
        },

        {
            path: 'serverdocker',
            redirectTo: 'serverdocker/servicelist',
            pathMatch: 'full'
        },
        {
            path: 'serverdocker/serviceInfo',
            redirectTo: 'serverdocker/serviceInfo/overview',
            pathMatch: 'full'
        },
        {
            path: 'policies',
            redirectTo: 'policies/policy',
            pathMatch: 'full'
        },
        {
            path: 'applications',
            component: ApplicationsComponent
        },
        {
            path: 'serverdocker',
            component: ServerdockerComponent,
            children: [
                {
                    path: 'servicelist',
                    component: ServicelistComponent
                },
                {
                    path: 'serviceInfo',
                    component: ServiceInfoComponent,
                    children: [
                        {
                            path: 'overview',
                            component: OverviewComponent
                        },
                        {
                            path: 'aggregateCPUUsage',
                            component: AggregateCPUUsageComponent
                        },
                        {
                            path: 'memoryUsage',
                            component: MemoryUsageComponent
                        },
                        {
                            path: 'fileSystem',
                            component: FileSystemComponent
                        },
                        {
                            path: 'disk',
                            component: DiskComponent
                        },
                        {
                            path: 'networkInterface',
                            component: NetworkInterfaceComponent
                        },
                        {
                            path: 'processInformation',
                            component: ProcessInformationComponent
                        }
                    ]
                }
            ]
        },
        {
            path: 'analytics',
            component: AnalyticsComponent
        },
        {
            path: 'middlewares',
            component: MiddlewaresComponent
        },
        {
            path: 'policies',
            component: PoliciesComponent,
            children: [
                {
                    path: 'policy',
                    component: PolicyComponent
                }
            ]
        },
        {
            path: 'nfvTrace',
            component: NFVTraceComponent
        },
    ])
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }

