import {Component} from '@angular/core';

declare var $: any;

@Component({
    moduleId: module.id,
    selector: 'sd-home',
    templateUrl: 'home.component.html'
})
export class HomeComponent {
    color: string;
    constructor(

    ) {}

    ngOnInit(): void {

    }
}
