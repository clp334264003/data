import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MiddlewaresComponent} from "./middlewares.component";
import {MiddlewaresRoutingModule} from "./middlewares-routing.module";
import {SharedModule} from "../shared/shared.module";

@NgModule({
  imports: [
    CommonModule,
    MiddlewaresRoutingModule,
    SharedModule
  ],
  declarations: [MiddlewaresComponent],
  exports: [MiddlewaresComponent]
})
export class MiddlewaresModule { }
