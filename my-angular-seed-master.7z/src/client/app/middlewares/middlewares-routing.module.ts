import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import {MiddlewaresComponent} from "./middlewares.component";


@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: 'middlewares',
        component: MiddlewaresComponent,
      }
    ])
  ],
  exports: [RouterModule]
})
export class MiddlewaresRoutingModule { }
