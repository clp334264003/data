import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'jhi-footer',
    templateUrl: 'footer.component.html'
})
export class FooterComponent {}
