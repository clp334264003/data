import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { APP_BASE_HREF } from '@angular/common';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared/shared.module';
import {HomeModule} from "./home/home.module";
import {customHttpProvider} from "./blocks/interceptor/http.provider";
import {LoginComponentModule} from "./login/login.component.module";
import {Ng2Webstorage} from "ng2-webstorage";
import {AnalyticsModule} from "./analytics/analytics.module";
import {ApplicationsModule} from "./applications/applications.module";
import {MiddlewaresModule} from "./middlewares/middlewares.module";
import {NFVTraceModule} from "./nfvTrace/nfvTrace.module";
import {PoliciesModule} from "./policies/policies.module";
import {ServerdockerModule} from "./serverdocker/serverdocker.module";



@NgModule({
    imports: [
        BrowserModule,
        AppRoutingModule,
        HomeModule,
        AnalyticsModule,
        ApplicationsModule,
        MiddlewaresModule,
        NFVTraceModule,
        PoliciesModule,
        ServerdockerModule,
        LoginComponentModule,
        Ng2Webstorage.forRoot({ prefix: 'jhi', separator: '-'}),
        SharedModule.forRoot()],
    declarations: [
        AppComponent
    ],
    providers: [
        { provide: Window, useValue: window },
        { provide: Document, useValue: document },
        customHttpProvider(),
        {
            provide: APP_BASE_HREF,
            useValue: '<%= APP_BASE %>'
        }
    ],
    bootstrap: [AppComponent]

})
export class AppModule { }
