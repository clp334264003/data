import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApplicationsComponent } from './applications.component';
import { ApplicationsRoutingModule } from './applications-routing.module';
import {SharedModule} from "../shared/shared.module";

@NgModule({
  imports: [
    CommonModule,
    ApplicationsRoutingModule,
    SharedModule
  ],
  declarations: [ApplicationsComponent],
  exports: [ApplicationsComponent]
})
export class ApplicationsModule { }
