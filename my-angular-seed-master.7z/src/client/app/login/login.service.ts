import { Injectable, Inject } from '@angular/core';
import {Principal} from "../shared/auth/principal.service";
import {AuthServerProvider} from "../shared/auth/auth-jwt.service";



@Injectable()
export class LoginService {
    constructor (
        private principal: Principal,
        private authServerProvider: AuthServerProvider
    ) {}

    login (credentials:any, callback?:any) {
        var cb = callback || function(){};

        return new Promise((resolve, reject) => {
            this.authServerProvider.login(credentials).subscribe(data => {
                //noinspection TypeScriptUnresolvedFunction
                this.principal.identity(true).then(account => {
                    console.log("======account========");
                    console.log(account);
                    console.log("======account========");
                    resolve(data);
                });
                return cb();
            }, err => {
                this.logout();
                reject(err);
                return cb(err);
            });
        });
    }

    loginWithToken(jwt:any, rememberMe:boolean) {
        return this.authServerProvider.loginWithToken(jwt, rememberMe);
    }

    logout () {
        this.authServerProvider.logout().subscribe();
        this.principal.authenticate(null);
    }
}
