import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {NFVTraceComponent} from "./nfvTrace.component";
import {NFVTraceRoutingModule} from "./nfvTrace-routing.module";
import {SharedModule} from "../shared/shared.module";

@NgModule({
  imports: [
    CommonModule,
    NFVTraceRoutingModule,
    SharedModule
  ],
  declarations: [NFVTraceComponent],
  exports: [NFVTraceComponent]
})
export class NFVTraceModule { }
