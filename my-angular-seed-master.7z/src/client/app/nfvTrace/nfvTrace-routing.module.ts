import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import {NFVTraceComponent} from "./nfvTrace.component";


@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: 'nfvTrace',
        component: NFVTraceComponent,
      }
    ])
  ],
  exports: [RouterModule]
})
export class NFVTraceRoutingModule { }
