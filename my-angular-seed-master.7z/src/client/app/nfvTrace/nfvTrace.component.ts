import {Component} from '@angular/core';
declare var $: any;
@Component({
    moduleId: module.id,
    selector: 'sd-nfvTrace',
    templateUrl: 'nfvTrace.component.html',
    styleUrls: ['nfvTrace.component.css'],
})
export class NFVTraceComponent {
    constructor() {
    }
}
