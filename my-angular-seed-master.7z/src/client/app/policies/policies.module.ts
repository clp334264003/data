import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {PoliciesComponent} from "./policies.component";
import {PoliciesRoutingModule} from "./policies-routing.module";
import {PolicyModule} from "./policy/policy.module";
import {SharedModule} from "../shared/shared.module";

@NgModule({
  imports: [
    CommonModule,
    PolicyModule,
    PoliciesRoutingModule,
    SharedModule
  ],
  declarations: [PoliciesComponent],
  exports: [PoliciesComponent]
})
export class PoliciesModule { }
