import {Component} from '@angular/core';
import {CookieService} from "angular2-cookie/services/cookies.service";
import {Router} from "@angular/router";
import {Http} from "@angular/http";
import moment = require("moment");
import {FormControl, FormGroup} from '@angular/forms';
import {MockCfg} from "../../mock";

declare var $: any;
@Component({
    moduleId: module.id,
    selector: 'sd-policy',
    templateUrl: 'policy.component.html',
    styleUrls: ['policy.component.css'],
    providers: [CookieService]
})
export class PolicyComponent {
    form: FormGroup;
    isLoading: boolean;
    policyDatas: any;
    submitted:boolean = false;
    private vm:any = {
        policyName:'',
    };
    multipleObjectType: boolean = false;
    optionsObjectType: Array<any> = [];
    constructor(
        private _cookieService: CookieService,
                private router: Router,
                private http: Http) {
        this.policyDatas = [];
        this.isLoading = false;
        this.queryPolicy();

        let numOptions = 100;
        let opts = new Array(numOptions);

        for (let i = 0; i < numOptions; i++) {
            opts[i] = {
                value: i.toString(),
                label: i.toString()
            };
        }

        this.optionsObjectType = opts.slice(0);
    }
    ngOnInit() {
        this.form = new FormGroup({});
        this.form.addControl('selectSingle', new FormControl(''));

    }
    queryPolicy() {
        this.isLoading = true;
        this.http.get(MockCfg.base8083Url + "/policy" ).subscribe(res=> {
            this.policyDatas = [];
            let data = res.json();
            console.log(data);
            if (data.status === 1) {
                this.policyDatas = data.data.policies;
            } else {
                // toastPolicyAtionMsg(0, data.resMsg);
            }
            this.isLoading = false;
        }, error=> {
            this.isLoading = false;
            console.log(error);
        });
    }

    login(){

    }

    onObjectTypeSingleOpened() {
        // this.logSingle('- opened');
    }

    onObjectTypeSingleClosed() {
        // this.logSingle('- closed');
    }

    onObjectTypeSingleSelected(item:any) {
       console.log('- selected (value: ' + item.value  + ', label:' +
            item.label + ')');
    }

    onObjectTypeSingleDeselected(item:any) {
        // this.logSingle('- deselected (value: ' + item.value  + ', label:' +
        //     item.label + ')');
    }

}
