import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {PolicyRoutingModule} from "./policy-routing.module";
import {PolicyComponent} from "./policy.component";
import {ReactiveFormsModule} from "@angular/forms";
import {SharedModule} from "../../shared/shared.module";


@NgModule({
  imports: [
    CommonModule,
    PolicyRoutingModule,
    ReactiveFormsModule,
    SharedModule
  ],
  declarations: [PolicyComponent],
  exports: [PolicyComponent]
})
export class PolicyModule { }
