package com.qm.smartsight.collector.web.rest;

import com.codahale.metrics.annotation.Timed;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.net.URISyntaxException;


/**
 * Created by root on 17-4-13.
 */
@RestController
@RequestMapping("/api")
public class UdpDataResource {
    private final Logger log = LoggerFactory.getLogger(UdpDataResource.class);

    @PostMapping("/udpData")
    @Timed
    public String createUdpData(@RequestBody String udpData) throws URISyntaxException {
        log.debug("REST request to save udpData : {}", udpData);

        return "ok";
    }

}
