package com.qm.smartsight.collector.web.rest;

import com.codahale.metrics.annotation.Timed;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URISyntaxException;

/**
 * Created by root on 17-4-13.
 */
@RestController
@RequestMapping("/api")
public class TAgentInfoResource {

    private final Logger log = LoggerFactory.getLogger(TAgentInfoResource.class);

    @PostMapping("/agentInfo")
    @Timed
    public String createTAgentInfo(@RequestBody String agentInfo) throws URISyntaxException {
        log.debug("REST request to save agentInfo : {}", agentInfo);

        return "ok";
    }
}
