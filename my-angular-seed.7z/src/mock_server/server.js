'use strict';


var restify = require('restify');
var server = restify.createServer();
server.use(restify.queryParser());
server.use(restify.requestLogger());
server.use(restify.bodyParser());

server.use(
    function crossOrigin(req, res, next) {
        'use strict';
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "X-Requested-With");
        return next();
    }
);

var chapter1 = require("./data/chapter1.json")
server.get("/api/chapter1", function(req, res, next) {
    res.send(chapter1)
    next()
})
var chapter1Tag = require("./data/chapter1Tag.json")
server.get("/api/chapter1Tag", function(req, res, next) {
    res.send(chapter1Tag)
    next()
})



var PORT = process.env.PORT || 8101;


server.listen(8101, function( /*req, res*/ ) {
    console.log('PDM api server listening on port ' + 8101);

});
