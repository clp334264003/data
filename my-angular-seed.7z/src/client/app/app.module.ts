import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { APP_BASE_HREF } from '@angular/common';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared/shared.module';
// import {AUTH_PROVIDERS, provideAuth} from "angular2-jwt";
import {HomeModule} from "./home/home.module";
import {customHttpProvider} from "./blocks/interceptor/http.provider";




@NgModule({
    imports: [
        BrowserModule,
        AppRoutingModule,
        HomeModule,
        SharedModule.forRoot()],
    declarations: [
        AppComponent
    ],
    providers: [
        // AUTH_PROVIDERS,
        // provideAuth({
        //     headerName: "authorization",
        //     headerPrefix: "Bearer",
        //     tokenName: "id_token",
        //     tokenGetter: (() => localStorage.getItem('authenticationToken')),
        //     globalHeaders: [{'Content-Type':'application/json'}],
        //     noJwtError: false,
        //     noTokenScheme: false
        // }),
        customHttpProvider(),
        {
            provide: APP_BASE_HREF,
            useValue: '<%= APP_BASE %>'
        }
    ],
    bootstrap: [AppComponent]

})
export class AppModule { }
