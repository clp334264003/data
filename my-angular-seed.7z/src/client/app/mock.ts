export class MockCfg {
    public static baseUrl1:string = 'http://localhost:8101';
    public static baseUrl:string = 'http://biblemapping.com';
    public static baseUrl2:string = 'http://23.239.8.157/church1/';
    public static readBaseUrl:string = MockCfg.baseUrl + '/node-bible-read';
    public static tagReadBaseUrl:string = MockCfg.baseUrl1 + '/api/chapter1Tag';
    public static chapter1Url:string = MockCfg.baseUrl1 + '/api/chapter1';

    public static getTermUrl:string = MockCfg.baseUrl2 + 'get_term_children/0';
    public static getTagsUrl:string = MockCfg.baseUrl2 + 'content_tags_read';

    public static getVerseUrl:string = MockCfg.baseUrl2 + 'term_read/';


}