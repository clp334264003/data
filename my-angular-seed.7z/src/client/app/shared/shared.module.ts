import {NgModule, ModuleWithProviders} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';
import {MaterialModule} from "@angular/material";
import {VariableService} from "./service/variable.service";
import {LoadingTableComponent} from "./table/loading-table.component";
import {EmptyTableComponent} from "./table/empty-table.component";
import {SelectModule} from "angular2-select";
import {Principal} from "./auth/principal.service";
import {AccountService} from "./auth/account.service";
import {AuthServerProvider} from "./auth/auth-jwt.service";
import {LocalStorageService, SessionStorageService} from "ng2-webstorage";
import {JhiLoginModalComponent} from "./login/login.component";
import {LoginService} from "./login/login.service";
import {LoginModalService} from "./login/login-modal.service";
import {NavbarComponent} from "./navbar/navbar.component";
import {StateStorageService} from "./auth/state-storage.service";
import {EventManager, NgJhipsterModule} from "ng-jhipster";
import {NgbModule} from "@ng-bootstrap/ng-bootstrap";




/**
 * Do not specify providers for modules that might be imported by a lazy loaded module.
 */

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        MaterialModule,
        NgbModule.forRoot(),
        // NgJhipsterModule.forRoot({
        // }),
    ],
    declarations: [
        NavbarComponent,
        JhiLoginModalComponent,
        LoadingTableComponent,
        EmptyTableComponent,

    ],
    entryComponents: [JhiLoginModalComponent],
    exports: [
        CommonModule,
        FormsModule,
        RouterModule,
        SelectModule,
        MaterialModule,
        JhiLoginModalComponent,
        NavbarComponent,
        LoadingTableComponent,
        EmptyTableComponent,
        NgbModule,
        // NgJhipsterModule,
    ]
})
export class SharedModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: SharedModule,
            providers: [
                EventManager,
                VariableService,
                LoginService,
                LoginModalService,
                Principal,
                AccountService,
                AuthServerProvider,
                LocalStorageService,
                StateStorageService,
                SessionStorageService
            ]
        };
    }
}
