import { serveSPA } from '../../utils';

/**
 * Executes the build process, serving the files of the development environment using an `express` server.
 */
export = serveSPA;
