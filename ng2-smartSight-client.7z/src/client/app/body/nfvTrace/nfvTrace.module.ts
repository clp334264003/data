import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SharedModule} from "../../shared/shared.module";
import {searchWithTimeModule} from "../../shared/searchWithTime/searchWithTime.module";
import {NFVTraceComponent} from "./nfvTrace.component";
import {NFVTraceRoutingModule} from "./nfvTrace-routing.module";


@NgModule({
  imports: [
    CommonModule,
    NFVTraceRoutingModule,
    searchWithTimeModule,
    SharedModule
  ],
  declarations: [NFVTraceComponent],
  exports: [NFVTraceComponent]
})
export class NFVTraceModule { }
