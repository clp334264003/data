import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {SharedModule} from "../../shared/shared.module";
import {searchWithTimeModule} from "../../shared/searchWithTime/searchWithTime.module";
import {PoliciesComponent} from "./policies.component";
import {PoliciesRoutingModule} from "./policies-routing.module";
import {PolicyModule} from "./policy/policy.module";

@NgModule({
  imports: [
    CommonModule,
    PolicyModule,
    PoliciesRoutingModule,
    searchWithTimeModule,
    SharedModule
  ],
  declarations: [PoliciesComponent],
  exports: [PoliciesComponent]
})
export class PoliciesModule { }
