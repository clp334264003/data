import {Component} from '@angular/core';
declare var $: any;
@Component({
    moduleId: module.id,
    selector: 'sd-policies',
    templateUrl: 'policies.component.html',
    styleUrls: ['policies.component.css'],
})
export class PoliciesComponent {
    constructor() {
    }
}
