import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {PolicyRoutingModule} from "./policy-routing.module";
import {PolicyComponent} from "./policy.component";
import {SharedModule} from "../../../shared/shared.module";
import {searchWithTimeModule} from "../../../shared/searchWithTime/searchWithTime.module";
import {ReactiveFormsModule} from "@angular/forms";



@NgModule({
  imports: [
    CommonModule,
    PolicyRoutingModule,
    ReactiveFormsModule,
    searchWithTimeModule,
    SharedModule
  ],
  declarations: [PolicyComponent],
  exports: [PolicyComponent]
})
export class PolicyModule { }
