import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ApplicationsComponent } from './index';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: 'applications',
        component: ApplicationsComponent,
      }
    ])
  ],
  exports: [RouterModule]
})
export class ApplicationsRoutingModule { }
