import {Component} from '@angular/core';
declare var $: any;
@Component({
    moduleId: module.id,
    selector: 'sd-applications',
    templateUrl: 'applications.component.html',
    styleUrls: ['applications.component.css'],
})
export class ApplicationsComponent {
    constructor() {
    }
}
