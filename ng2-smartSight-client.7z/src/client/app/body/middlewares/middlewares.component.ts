import {Component} from '@angular/core';
declare var $: any;
@Component({
    moduleId: module.id,
    selector: 'sd-middlewares',
    templateUrl: 'middlewares.component.html',
    styleUrls: ['middlewares.component.css'],
})
export class MiddlewaresComponent {
    constructor() {
    }
}
