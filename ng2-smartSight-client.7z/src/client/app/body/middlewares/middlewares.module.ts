import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {SharedModule} from "../../shared/shared.module";
import {searchWithTimeModule} from "../../shared/searchWithTime/searchWithTime.module";
import {MiddlewaresComponent} from "./middlewares.component";
import {MiddlewaresRoutingModule} from "./middlewares-routing.module";


@NgModule({
  imports: [
    CommonModule,
    MiddlewaresRoutingModule,
    searchWithTimeModule,
    SharedModule
  ],
  declarations: [MiddlewaresComponent],
  exports: [MiddlewaresComponent]
})
export class MiddlewaresModule { }
