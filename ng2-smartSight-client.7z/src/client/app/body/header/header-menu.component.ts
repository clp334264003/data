import {Component, ElementRef} from '@angular/core';
import {Router} from "@angular/router";


@Component({
  moduleId: module.id,
  selector:'header-menu',
  templateUrl:'header-menu.component.html',
  styleUrls:['header-menu.component.css']
})

export class HeaderMenuComponent {
  private user:any;
  language:string ;
    languageFlag:boolean;// false  en-US
  constructor(
      private router: Router
  ) {
    this.user = {};
    if(localStorage.getItem("lang") == "en-US"){
      this.language = "English";
        this.languageFlag = false;
    }
    else if(localStorage.getItem("lang") == "zh-CN"){
      this.language = "Chinese";
        this.languageFlag = true;
    }
    else {
        this.language = "English";
        this.languageFlag = false;
    }
      this.lang = localStorage.getItem('lang') || 'en-US';
  }
  public lang: string;

  public selectLanguage = () => {
    if(this.language == "English"){
      this.language = "Chinese";
        this.languageFlag = true;
        localStorage.setItem('lang', "zh-CN");
    }
    else {
      this.language = "English";
        this.languageFlag = false;
        localStorage.setItem('lang', "en-US");
    }
    window.location.href = this.router.url;
  }
}

