import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ServicelistComponent} from "./servicelist.component";
import {ServicelistRoutingModule} from "./servicelist-routing.module";
import {SharedModule} from "../../../shared/shared.module";
import {searchWithTimeModule} from "../../../shared/searchWithTime/searchWithTime.module";

@NgModule({
    imports: [
        CommonModule,
        ServicelistRoutingModule,
        searchWithTimeModule,
        SharedModule
    ],
    declarations: [
        ServicelistComponent,

    ],
    exports: [ServicelistComponent]
})
export class ServicelistModule { }
