import {Component} from '@angular/core';
import {Http} from "@angular/http";

import {CookieService} from "angular2-cookie/services/cookies.service";
import {OverviewService} from "./overview/overview.service";
import {Router} from "@angular/router";
declare var $: any;

@Component({
    moduleId: module.id,
    selector: 'sd-serviceInfo',
    templateUrl: 'serviceInfo.component.html',
    styleUrls: ['serviceInfo.component.css']
})
export class ServiceInfoComponent {
    isLoading:boolean;
    private server:any= {
        application: "",
        service: "",
        hostid: ""
    };

    from:any;
    to:any;
    constructor(
        private _cookieService:CookieService,
        private _overviewService: OverviewService,
        private router: Router,
        private http: Http
    ) {
        this.server = this._cookieService.getObject("server");
        this.isLoading = false;
    }
    searchByTime(data:any) {
        // let start = moment.unix(data.startTime).valueOf()/1000;
        // let end = moment.unix(data.endTime).valueOf()/1000;
        // if(this.router.url == "/body/serverdocker/serviceInfo/overview"){
        //     console.log((start-end)/1000)
        //     this._overviewService.updateoverViewDatas(start,end);
        // }
        // else {
        //
        // }
        // console.log(this.router.url)
    }
}
