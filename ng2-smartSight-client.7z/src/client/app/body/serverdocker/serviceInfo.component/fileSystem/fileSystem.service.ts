import {Injectable}     from '@angular/core';
import {MockCfg} from "../../../../mock";
import {Http} from "@angular/http";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {EchartsTheme} from "../../../../shared/theme/echarts.theme";

declare var $: any;
declare var echarts: any;
@Injectable(

)
export class FileSystemService {
    public server: any = {
        application: "",
        service: "",
        hostid: ""
    };
    public myAggregatefilesystemusageChart: any;
    public myAggregatefilesystemspaceusageChart: any;

    constructor(private _echartsTheme: EchartsTheme,
                private _cookieService: CookieService,
                private http: Http) {
        this.server = this._cookieService.getObject("server");
    }

    // 请求 fileSystem 页面数据
    fileSystemDatas:any = [];
    isLoading = false;

    updatefileSystemDatas(from:number,to:number) {
        let serverInfofileSystemUrl: string = "";
        if (MockCfg.getMockFlag()) {
            serverInfofileSystemUrl = MockCfg.serverMockdataSourceURL() + "/api/fileSystem?hostid=" + this.server.hostid + "&from=" + from + "&to=" + to;
        }
        else {
            serverInfofileSystemUrl = MockCfg.dataSourceURL() + "/hosts/host/" + this.server.hostid + "/fileSystem.pinpoint?from=" + from + "&to=" + to;
        }
        console.log("serverInfofileSystemUrl:" + serverInfofileSystemUrl);
        this.initfileSystemDatas();

        this.isLoading = true;
        this.fileSystemDatas = [];

        this.http.get(serverInfofileSystemUrl).subscribe(res=> {
            let response = res.json();
            console.log("---updatefileSystemDatas---");
            console.log(response);
            console.log("---updatefileSystemDatas---");
            this.isLoading = false;
            this.fileSystemDatas = response["fileSystem"]["fileSystemDatas"];

            // 更新 聚集文件系统使用情况
            let myAggregatefilesystemusageChartOptions = this.myAggregatefilesystemusageChart.getOption();
            myAggregatefilesystemusageChartOptions = this.myAggregatefilesystemusageChartOption;
            myAggregatefilesystemusageChartOptions.series[0].data = response["fileSystem"]["aggregatefilesystemusage"]["percentageUsed"];
            myAggregatefilesystemusageChartOptions.series[1].data = response["fileSystem"]["aggregatefilesystemusage"]["availablePercentage"];
            myAggregatefilesystemusageChartOptions.xAxis.data = response["fileSystem"]["aggregatefilesystemusage"]["time"];
            this.myAggregatefilesystemusageChart.hideLoading();
            this.myAggregatefilesystemusageChart.setOption(myAggregatefilesystemusageChartOptions);

            // 更新 聚集文件系统空间使用情况
            let myAggregatefilesystemspaceusageChartOptions = this.myAggregatefilesystemspaceusageChart.getOption();
            myAggregatefilesystemspaceusageChartOptions = this.myAggregatefilesystemspaceusageChartOption;
            myAggregatefilesystemspaceusageChartOptions.series[0].data = response["fileSystem"]["aggregatefilesystemspaceusage"]["used"];
            myAggregatefilesystemspaceusageChartOptions.series[1].data = response["fileSystem"]["aggregatefilesystemspaceusage"]["total"];
            myAggregatefilesystemspaceusageChartOptions.xAxis.data = response["fileSystem"]["aggregatefilesystemspaceusage"]["time"];
            this.myAggregatefilesystemspaceusageChart.hideLoading();
            this.myAggregatefilesystemspaceusageChart.setOption(myAggregatefilesystemspaceusageChartOptions);

        }, error=> {
            console.log(error);
            this.isLoading = false;
        });


    }

    initfileSystemDatas() {
        // 更新 聚集文件系统使用情况
        // this.myAggregatefilesystemusageChart = echarts.init(document.getElementById("myAggregatefilesystemusageChartID"), this._echartsTheme.theme);
        let myAggregatefilesystemusageChartOptions = this.myAggregatefilesystemusageChart.getOption();
        myAggregatefilesystemusageChartOptions = this.myAggregatefilesystemusageChartOption;
        myAggregatefilesystemusageChartOptions.series[0].data = [];
        myAggregatefilesystemusageChartOptions.series[1].data = [];
        myAggregatefilesystemusageChartOptions.xAxis.data = [];
        this.myAggregatefilesystemusageChart.showLoading({
            text: "loading..."
        });
        this.myAggregatefilesystemusageChart.setOption(myAggregatefilesystemusageChartOptions);

        // 更新 聚集文件系统空间使用情况
        // this.myAggregatefilesystemspaceusageChart = echarts.init(document.getElementById("myAggregatefilesystemspaceusageChartID"), this._echartsTheme.theme);
        let myAggregatefilesystemspaceusageChartOptions = this.myAggregatefilesystemspaceusageChart.getOption();
        myAggregatefilesystemspaceusageChartOptions = this.myAggregatefilesystemspaceusageChartOption;
        myAggregatefilesystemspaceusageChartOptions.series[0].data = [];
        myAggregatefilesystemspaceusageChartOptions.series[1].data = [];
        myAggregatefilesystemspaceusageChartOptions.xAxis.data = [];
        this.myAggregatefilesystemspaceusageChart.showLoading({
            text: "loading..."
        });
        this.myAggregatefilesystemspaceusageChart.setOption(myAggregatefilesystemspaceusageChartOptions);
        echarts.connect([this.myAggregatefilesystemusageChart, this.myAggregatefilesystemspaceusageChart]);
    }

// fileSystem 页面数据
    myAggregatefilesystemusageChartOption = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            orient: 'horizontal',
            x: 'center', // 'center' | 'left' | {number},
            y: 'bottom', //
            padding: 0,    // [5, 10, 15, 20]
            itemGap: 20,
            data: ['%used', '%available']
        },
        xAxis: {
            type: 'category',
            name: 'time',
            nameLocation: 'middle',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '25',
            boundaryGap: false,
            data: ['2017-2-7 8:55', '2017-2-7 8:56', '2017-2-7 8:57', '2017-2-7 8:58', '2017-2-7 8:59', '2017-2-7 9:00', '2017-2-7 9:01']
        },
        yAxis: {
            type: 'value',
            name: '%',
            max: 100,
            nameLocation: 'end',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '15'
        },
        series: [
            {
                name: '%used',
                type: 'line',
                stack: '总量',
                data: [24, 24, 24, 24, 24, 24, 24]
            },
            {
                name: '%available',
                type: 'line',
                data: [76, 76, 76, 76, 76, 76, 76]
            }
        ]
    };

    myAggregatefilesystemspaceusageChartOption = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            orient: 'horizontal',
            x: 'center', // 'center' | 'left' | {number},
            y: 'bottom', //
            padding: 0,    // [5, 10, 15, 20]
            itemGap: 20,
            data: ['size', 'Used']
        },
        xAxis: {
            type: 'category',
            name: 'time',
            nameLocation: 'middle',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '25',
            boundaryGap: false,
            data: ['2017-2-7 8:55', '2017-2-7 8:56', '2017-2-7 8:57', '2017-2-7 8:58', '2017-2-7 8:59', '2017-2-7 9:00', '2017-2-7 9:01']
        },
        yAxis: {
            type: 'value',
            name: 'MB',
            nameLocation: 'end',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '15'
        },
        series: [
            {
                name: 'size',
                type: 'line',
                stack: '总量',
                data: [160000, 160000, 160000, 160000, 160000, 160000, 160000]
            },
            {
                name: 'Used',
                type: 'line',
                stack: '总量',
                data: [650000, 650000, 650000, 650000, 650000, 650000, 650000]
            }
        ]
    };
}

