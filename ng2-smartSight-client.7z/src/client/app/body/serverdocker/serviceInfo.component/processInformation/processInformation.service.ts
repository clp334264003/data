import {Injectable}     from '@angular/core';
import {MockCfg} from "../../../../mock";
import {Http} from "@angular/http";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {EchartsTheme} from "../../../../shared/theme/echarts.theme";

declare var $: any;
declare var echarts: any;
@Injectable()
export class DiskService {
    public server: any = {
        application: "",
        service: "",
        hostid: ""
    };
    public myDiskoperationsChart: any;
    public myDiskusageChart: any;

    constructor(private _echartsTheme: EchartsTheme,
                private _cookieService: CookieService,
                private http: Http) {
        this.server = this._cookieService.getObject("server");

    }

// 请求 disk 页面数据
    diskDatas:any = [];
    isLoading = false;

    updatediskDatas(from: number, to: number) {
        let serverInfodiskUrl: string = "";
        if (MockCfg.getMockFlag()) {
            serverInfodiskUrl = MockCfg.serverMockdataSourceURL() + "/api/disk?hostid=" + this.server.hostid + "from=" + from + "&to=" + to;
        }
        else {
            serverInfodiskUrl = MockCfg.dataSourceURL() + "/hosts/host/" + this.server.hostid + "/disk.pinpoint?from=" + from + "&to=" + to;
        }
        console.log("serverInfodiskUrl:" + serverInfodiskUrl);
        this.initdiskDatas();

        this.isLoading = true;
        this.diskDatas = [];

        this.http.get(serverInfodiskUrl).subscribe(res=> {
            let response = res.json();
            console.log("---updatediskDatas---");
            console.log(response);
            console.log("---updatediskDatas---");
            this.isLoading = false;
            this.diskDatas = response["disk"]["diskDatas"];

            // 更新 聚焦每秒磁盘操作数
            let myDiskoperationsChartOptions = this.myDiskoperationsChart.getOption();
            myDiskoperationsChartOptions = this.myDiskoperationsChartOption;
            myDiskoperationsChartOptions.series[0].data = response["disk"]["diskoperations"]["readsTheNumberOfBlocksPerSecond"];
            myDiskoperationsChartOptions.series[1].data = response["disk"]["diskoperations"]["numberOfBlocksWrittenPerSecond"];
            myDiskoperationsChartOptions.xAxis.data = response["disk"]["diskoperations"]["time"];
            this.myDiskoperationsChart.hideLoading();
            this.myDiskoperationsChart.setOption(myDiskoperationsChartOptions);

            // 更新 聚焦磁盘I/O使用情况
            let myDiskusageChartOptions = this.myDiskusageChart.getOption();
            myDiskusageChartOptions = this.myDiskusageChartOption;
            myDiskusageChartOptions.series[0].data = response["disk"]["diskusage"]["numberOfTransfersPerSecond"];
            myDiskusageChartOptions.xAxis.data = response["disk"]["diskusage"]["time"];
            this.myDiskusageChart.hideLoading();
            this.myDiskusageChart.setOption(myDiskusageChartOptions);
        }, error=> {
            console.log(error);
            this.isLoading = false;
        });
    }

    initdiskDatas() {
        // 更新 聚焦每秒磁盘操作数
        // this.myDiskoperationsChart = echarts.init(document.getElementById("myDiskoperationsChartID"), this._echartsTheme.theme);
        var myDiskoperationsChartOptions = this.myDiskoperationsChart.getOption();
        myDiskoperationsChartOptions = this.myDiskoperationsChartOption;
        myDiskoperationsChartOptions.series[0].data = [];
        myDiskoperationsChartOptions.series[1].data = [];
        myDiskoperationsChartOptions.xAxis.data = [];
        this.myDiskoperationsChart.showLoading({
            text: "loading..."
        });
        this.myDiskoperationsChart.setOption(myDiskoperationsChartOptions);

        // 更新 聚焦磁盘I/O使用情况
        // this.myDiskusageChart = echarts.init(document.getElementById("myDiskusageChartID"), this._echartsTheme.theme);
        var myDiskusageChartOptions = this.myDiskusageChart.getOption();
        myDiskusageChartOptions = this.myDiskusageChartOption;
        myDiskusageChartOptions.series[0].data = [];
        myDiskusageChartOptions.xAxis.data = [];
        this.myDiskusageChart.showLoading({
            text: "loading..."
        });
        this.myDiskusageChart.setOption(myDiskusageChartOptions);
        echarts.connect([this.myDiskoperationsChart, this.myDiskusageChart]);
    }

// disk 页面数据
    myDiskoperationsChartOption = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            orient: 'horizontal',
            x: 'center',
            y: 'bottom',
            padding: 0,
            itemGap: 20,
            data: ['Blk_read/s', 'Blk_wrtn/s']
        },
        xAxis: {
            type: 'category',
            name: 'time',
            nameLocation: 'middle',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '25',
            boundaryGap: false,
            data: ['', '', '', '', '', '', '', '', '', '', '', '', '', '']
        },
        yAxis: {
            type: 'value',
            name: 'Blk/s',
            nameLocation: 'end',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '15'
        },
        series: [
            {
                name: 'Blk_read/s',
                type: 'line',
                data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            },
            {
                name: 'Blk_wrtn/s',
                type: 'line',
                data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            }
        ]
    };

    myDiskusageChartOption = {
        tooltip: {
            trigger: 'axis'
        },
        xAxis: {
            type: 'category',
            name: 'time',
            nameLocation: 'middle',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '25',
            boundaryGap: false,
            data: ['', '', '', '', '', '', '', '', '', '', '', '', '', '']

        },
        yAxis: {
            type: 'value',
            name: 'tps',
            nameLocation: 'end',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '15'
        },
        series: [
            {
                name: 'tps',
                type: 'line',
                data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            }
        ]
    };

}

