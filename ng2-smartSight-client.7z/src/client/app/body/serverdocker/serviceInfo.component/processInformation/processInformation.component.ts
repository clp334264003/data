import {Component} from '@angular/core';
import {PartProcessInformationService} from "../partProcessInformation/partProcessInformation.service";
declare var $: any;
@Component({
    moduleId: module.id,
    selector: 'sd-processInformation',
    templateUrl: 'processInformation.component.html',
    styleUrls: ['processInformation.component.css'],
})
export class ProcessInformationComponent {
    constructor(private _partProcessInformationService: PartProcessInformationService) {
        this._partProcessInformationService.showFlag = {
            showTop5CPU_Usage:true,
            showTop5CPU_TIME:true,
            showTop5VIRT:true,
        };
        this._partProcessInformationService.updateprocessInformationDatas(null);
    }
}
