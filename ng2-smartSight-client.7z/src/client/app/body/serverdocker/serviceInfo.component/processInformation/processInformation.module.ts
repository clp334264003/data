import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SharedModule} from "../../../../shared/shared.module";
import {ProcessInformationComponent} from "./processInformation.component";
import {PartProcessInformationModule} from "../partProcessInformation/partProcessInformation.module";
import {PartProcessInformationService} from "../partProcessInformation/partProcessInformation.service";


@NgModule({
    imports: [
        CommonModule,
        PartProcessInformationModule,
        SharedModule

    ],
    declarations: [ProcessInformationComponent],
    exports: [ProcessInformationComponent],
    providers: [PartProcessInformationService]
})
export class ProcessInformationModule { }
