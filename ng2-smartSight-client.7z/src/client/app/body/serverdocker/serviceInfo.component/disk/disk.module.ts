import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SharedModule} from "../../../../shared/shared.module";
import {DiskComponent} from "./disk.component";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {EchartsTheme} from "../../../../shared/theme/echarts.theme";
import {DiskService} from "./disk.service";


@NgModule({
    imports: [
        CommonModule,
        SharedModule
    ],
    declarations: [DiskComponent],
    exports: [DiskComponent],
    providers: [CookieService, EchartsTheme, DiskService]
})
export class DiskModule { }
