import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {OverviewComponent} from "./overview.component";
import {SharedModule} from "../../../../shared/shared.module";
import {searchWithTimeModule} from "../../../../shared/searchWithTime/searchWithTime.module";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {VariableService} from "../../../../shared/service/variable.service";
import {EchartsTheme} from "../../../../shared/theme/echarts.theme";
import {OverviewService} from "./overview.service";


@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        searchWithTimeModule
    ],
    declarations: [OverviewComponent],
    exports: [OverviewComponent],
    providers: [CookieService, VariableService, EchartsTheme, OverviewService]
})
export class OverviewModule { }
