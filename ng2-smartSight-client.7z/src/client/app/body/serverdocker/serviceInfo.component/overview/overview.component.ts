import {Component} from '@angular/core';
import {EchartsTheme} from "../../../../shared/theme/echarts.theme";

import {CookieService} from "angular2-cookie/services/cookies.service";
import {OverviewService} from "./overview.service";

declare var $: any;
declare var echarts: any;
var moment = require('moment');
@Component({
    moduleId: module.id,
    selector: 'sd-overview',
    templateUrl: 'overview.component.html',
    styleUrls: ['overview.component.css'],
})
export class OverviewComponent {
    constructor(private _echartsTheme: EchartsTheme,
                private _cookieService: CookieService,
                private _overviewService: OverviewService) {
    }

    ngAfterViewInit() {
        this._overviewService.myCpuChart = echarts.init(document.getElementById("myCpuChartID"), this._echartsTheme.theme);
        this._overviewService.myCpuChart.setOption(this._overviewService.myCpuChartOption);
        this._overviewService.mySmemoryChart = echarts.init(document.getElementById("mySmemoryChartID"), this._echartsTheme.theme);
        this._overviewService.mySmemoryChart.setOption(this._overviewService.mySmemoryChartOption);
        this._overviewService.myTopfivefileststemChart = echarts.init(document.getElementById("myTopfivefileststemID"), this._echartsTheme.theme);
        this._overviewService.myTopfivefileststemChart.setOption(this._overviewService.myTopfivefileststemOption);
        this._overviewService.myTopfivediskChart = echarts.init(document.getElementById("myTopfivediskID"), this._echartsTheme.theme);
        this._overviewService.myTopfivediskChart.setOption(this._overviewService.myTopfivediskOption);
        this._overviewService.myToptennetworkinterfaceChart = echarts.init(document.getElementById("myToptennetworkinterfaceID"), this._echartsTheme.theme);
        this._overviewService.myToptennetworkinterfaceChart.setOption(this._overviewService.myToptennetworkinterfaceOption);

        let timeCookie: any = this._cookieService.getObject("timeCookie");
        let start:any;
        let end:any;
        if (timeCookie) {
            start = timeCookie.startTime;
            end = timeCookie.endTime;
        }
        else {
            start = moment().subtract(10, 'minutes');
            end = moment();
        }
         start = moment.unix(start).valueOf() / 1000;
         end = moment.unix(end).valueOf() / 1000;
        this._overviewService.updateoverViewDatas(start, end);
    }
}
