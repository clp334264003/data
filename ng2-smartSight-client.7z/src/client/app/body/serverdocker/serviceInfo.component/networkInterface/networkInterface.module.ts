import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SharedModule} from "../../../../shared/shared.module";
import {NetworkInterfaceComponent} from "./networkInterface.component";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {EchartsTheme} from "../../../../shared/theme/echarts.theme";
import {NetworkInterfaceService} from "./networkInterface.service";



@NgModule({
    imports: [
        CommonModule,
        SharedModule
    ],
    declarations: [NetworkInterfaceComponent],
    exports: [NetworkInterfaceComponent],
    providers: [CookieService, EchartsTheme, NetworkInterfaceService]
})
export class NetworkInterfaceModule { }
