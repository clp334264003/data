import {Injectable}     from '@angular/core';
import {MockCfg} from "../../../../mock";
import {Http} from "@angular/http";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {EchartsTheme} from "../../../../shared/theme/echarts.theme";

declare var $: any;
declare var echarts: any;
@Injectable()
export class NetworkInterfaceService {
    public server: any = {
        application: "",
        service: "",
        hostid: ""
    };
    public myAggregatenetworkinterfaceiorateChart: any;
    public myAggregatenetworkinterfaceerrorChart: any;

    constructor(private _echartsTheme: EchartsTheme,
                private _cookieService: CookieService,
                private http: Http) {
        this.server = this._cookieService.getObject("server");

    }

// 请求 networkInterface 页面数据

    networkInterfaceDatas:any = [];

    isLoading = false;

    updatenetworkInterfaceDatas(from:number,to:number) {
        let serverInfonetworkInterfaceUrl: string = "";
        if (MockCfg.getMockFlag()) {
            serverInfonetworkInterfaceUrl = MockCfg.serverMockdataSourceURL() + "/api/networkInterface?hostid=" + this.server.hostid + "from=" + from + "&to=" + to;
        }
        else {
            serverInfonetworkInterfaceUrl = MockCfg.dataSourceURL() + "/hosts/host/" + this.server.hostid + "/networkInterface.pinpoint?from=" + from + "&to=" + to;
        }
        console.log("serverInfonetworkInterfaceUrl:" + serverInfonetworkInterfaceUrl);
        this.initnetworkInterfaceDatas();
        this.isLoading = true;
        this.networkInterfaceDatas = [];
        this.http.get(serverInfonetworkInterfaceUrl).subscribe(res=> {
            let response = res.json();
            console.log("---updatenetworkInterfaceDatas---");
            console.log(response);
            console.log("---updatenetworkInterfaceDatas---");
            this.networkInterfaceDatas = response["networkInterface"]["networkInterfaceDatas"];
            this.isLoading = false;
            // 更新 聚焦每秒磁盘操作数
            var myAggregatenetworkinterfaceiorateChartOptions = this.myAggregatenetworkinterfaceiorateChart.getOption();
            myAggregatenetworkinterfaceiorateChartOptions = this.myAggregatenetworkinterfaceiorateChartOption;
            myAggregatenetworkinterfaceiorateChartOptions.series[0].data = response["networkInterface"]["aggregatenetworkinterfaceiorate"]["theNumberOfKilobytesReceivedPerSecond"];
            myAggregatenetworkinterfaceiorateChartOptions.series[1].data = response["networkInterface"]["aggregatenetworkinterfaceiorate"]["theNumberOfKilobytesTransferredPerSecond"];
            myAggregatenetworkinterfaceiorateChartOptions.xAxis.data = response["networkInterface"]["aggregatenetworkinterfaceiorate"]["time"];
            this.myAggregatenetworkinterfaceiorateChart.hideLoading();
            this.myAggregatenetworkinterfaceiorateChart.setOption(myAggregatenetworkinterfaceiorateChartOptions);

            // 更新 聚焦磁盘I/O使用情况
            var myAggregatenetworkinterfaceerrorChartOptions = this.myAggregatenetworkinterfaceerrorChart.getOption();
            myAggregatenetworkinterfaceerrorChartOptions = this.myAggregatenetworkinterfaceerrorChartOption;
            myAggregatenetworkinterfaceerrorChartOptions.series[0].data = response["networkInterface"]["aggregatenetworkinterfaceerror"]["theNumberOfPacketConflicts"];
            myAggregatenetworkinterfaceerrorChartOptions.series[1].data = response["networkInterface"]["aggregatenetworkinterfaceerror"]["theNumberOfPacketInputErrors"];
            myAggregatenetworkinterfaceerrorChartOptions.series[2].data = response["networkInterface"]["aggregatenetworkinterfaceerror"]["theNumberOfPacketOutputErrors"];
            myAggregatenetworkinterfaceerrorChartOptions.xAxis.data = response["networkInterface"]["aggregatenetworkinterfaceerror"]["time"];
            this.myAggregatenetworkinterfaceerrorChart.hideLoading();
            this.myAggregatenetworkinterfaceerrorChart.setOption(myAggregatenetworkinterfaceerrorChartOptions);
        }, error=> {
            console.log(error);
            this.isLoading = false;
        });
    }

    initnetworkInterfaceDatas() {
        // 更新 聚焦每秒磁盘操作数
        // this.myAggregatenetworkinterfaceiorateChart = echarts.init(document.getElementById("myAggregatenetworkinterfaceiorateChartID"), this._echartsTheme.theme);
        var myAggregatenetworkinterfaceiorateChartOptions = this.myAggregatenetworkinterfaceiorateChart.getOption();
        myAggregatenetworkinterfaceiorateChartOptions = this.myAggregatenetworkinterfaceiorateChartOption;
        myAggregatenetworkinterfaceiorateChartOptions.series[0].data = [];
        myAggregatenetworkinterfaceiorateChartOptions.series[1].data = [];
        myAggregatenetworkinterfaceiorateChartOptions.xAxis.data = [];
        this.myAggregatenetworkinterfaceiorateChart.showLoading({
            text: "loading..."
        });
        this.myAggregatenetworkinterfaceiorateChart.setOption(myAggregatenetworkinterfaceiorateChartOptions);

        // 更新 聚焦磁盘I/O使用情况
        // this.myAggregatenetworkinterfaceerrorChart = echarts.init(document.getElementById("myAggregatenetworkinterfaceerrorChartID"), this._echartsTheme.theme);
        var myAggregatenetworkinterfaceerrorChartOptions = this.myAggregatenetworkinterfaceerrorChart.getOption();
        myAggregatenetworkinterfaceerrorChartOptions = this.myAggregatenetworkinterfaceerrorChartOption;
        myAggregatenetworkinterfaceerrorChartOptions.series[0].data = [];
        myAggregatenetworkinterfaceerrorChartOptions.series[1].data = [];
        myAggregatenetworkinterfaceerrorChartOptions.series[2].data = [];
        myAggregatenetworkinterfaceerrorChartOptions.xAxis.data = [];
        this.myAggregatenetworkinterfaceerrorChart.showLoading({
            text: "loading..."
        });
        this.myAggregatenetworkinterfaceerrorChart.setOption(myAggregatenetworkinterfaceerrorChartOptions);
        echarts.connect([this.myAggregatenetworkinterfaceiorateChart, this.myAggregatenetworkinterfaceerrorChart]);
    }

    // networkInterface 页面数据
    myAggregatenetworkinterfaceiorateChartOption = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            orient: 'horizontal',
            x: 'center',
            y: 'bottom',
            padding: 0,
            itemGap: 20,
            data: ['receive', 'transmit']
        },
        xAxis: {
            type: 'category',
            name: 'time',
            nameLocation: 'middle',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '25',
            boundaryGap: false,
            data: ['2017-2-7 8:55', '2017-2-7 8:56', '2017-2-7 8:57', '2017-2-7 8:58', '2017-2-7 8:59', '2017-2-7 9:00', '2017-2-7 9:01']
        },
        yAxis: {
            type: 'value',
            name: 'kb/s',
            nameLocation: 'end',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '15'
        },
        series: [
            {
                name: 'receive',
                type: 'line',
                stack: '总量',
                data: [0.8, 0.9, 1.1, 1.2, 0.5, 0.8, 0.9]
            },
            {
                name: 'transmit',
                type: 'line',
                stack: '总量',
                data: [1.5, 2.5, 1.6, 1.5, 2.5, 1.8, 1.6]
            }
        ]
    };
    myAggregatenetworkinterfaceerrorChartOption = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            orient: 'horizontal',
            x: 'center',
            y: 'bottom',
            padding: 0,
            itemGap: 20,
            data: ['colls', 'errs_Receive', 'errs_Transmit']
        },
        xAxis: {
            type: 'category',
            name: 'time',
            nameLocation: 'middle',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '25',
            boundaryGap: false,
            data: ['2017-2-7 8:55', '2017-2-7 8:56', '2017-2-7 8:57', '2017-2-7 8:58', '2017-2-7 8:59', '2017-2-7 9:00', '2017-2-7 9:01']
        },
        yAxis: {
            type: 'value',
            name: 'packets',
            nameLocation: 'end',
            nameTextStyle: {
                fontStyle: 'italic',
                fontWeight: 'bolder',
                fontSize: '16'
            },
            nameGap: '15'
        },
        series: [
            {
                name: 'colls',
                type: 'line',
                stack: '总量',
                data: [0, 0, 0, 0, 0, 0, 0]
            },
            {
                name: 'errs_Receive',
                type: 'line',
                stack: '总量',
                data: [0, 0, 0, 0, 0, 0, 0]
            },
            {
                name: 'errs_Transmit',
                type: 'line',
                stack: '总量',
                data: [0, 0, 0, 0, 0, 0, 0]
            }
        ]
    };

}

