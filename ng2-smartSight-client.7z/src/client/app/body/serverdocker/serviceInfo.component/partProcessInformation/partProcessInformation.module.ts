import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SharedModule} from "../../../../shared/shared.module";
import {PartProcessInformationComponent} from "./partProcessInformation.component";
import {CookieService} from "angular2-cookie/services/cookies.service";
import {EchartsTheme} from "../../../../shared/theme/echarts.theme";
import {PartProcessInformationService} from "./partProcessInformation.service";



@NgModule({
    imports: [
        CommonModule,
        SharedModule
    ],
    declarations: [PartProcessInformationComponent],
    exports: [PartProcessInformationComponent],
    providers: [CookieService, EchartsTheme, PartProcessInformationService]
})
export class PartProcessInformationModule { }
