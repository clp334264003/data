import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SharedModule} from "../../shared/shared.module";
import {HighlightDirective} from "../../shared/directive/myHighlight.directive";
import {ServerdockerComponent} from "./serverdocker.component";
import {ServicelistModule} from "./servicelist.component/servicelist.module";
import {serviceInfoModule} from "./serviceInfo.component/serviceInfo.module";

@NgModule({
    imports: [
        CommonModule,
        ServicelistModule,
        serviceInfoModule,
        SharedModule
    ],
    declarations: [ServerdockerComponent,HighlightDirective],
    exports: [ServerdockerComponent]
})
export class ServerdockerModule { }
