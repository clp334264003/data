import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import {ServerdockerComponent} from "./serverdocker.component";
import {ServicelistComponent} from "./servicelist.component/servicelist.component";
import {ServiceInfoComponent} from "./serviceInfo.component/serviceInfo.component";
import {OverviewComponent} from "./serviceInfo.component/overview/overview.component";
import {DiskComponent} from "./serviceInfo.component/disk/disk.component";

@NgModule({
    imports: [
        RouterModule.forChild([

        ])
    ],
    exports: [RouterModule]
})
export class ServerdockerRoutingModule { }