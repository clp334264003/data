import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {SharedModule} from "../../shared/shared.module";
import {searchWithTimeModule} from "../../shared/searchWithTime/searchWithTime.module";
import {AnalyticsComponent} from "./analytics.component";
import {AnalyticsRoutingModule} from "./analytics-routing.module";

@NgModule({
  imports: [
    CommonModule,
    AnalyticsRoutingModule,
    searchWithTimeModule,
    SharedModule
  ],
  declarations: [AnalyticsComponent],
  exports: [AnalyticsComponent]
})
export class AnalyticsModule { }
