import {Component} from '@angular/core';
declare var $: any;
@Component({
    moduleId: module.id,
    selector: 'sd-analytics',
    templateUrl: 'analytics.component.html',
    styleUrls: ['analytics.component.css'],
})
export class AnalyticsComponent {
    constructor() {
    }
}
