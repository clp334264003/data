import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {BodyComponent} from './body.component';
import {BodyRoutingModule} from './body-routing.module';
import {SharedModule} from '../shared/shared.module';
import {ApplicationsModule} from "./applications/applications.module";
import {ServerdockerModule} from "./serverdocker/serverdocker.module";
import {HeaderMenuModule} from "./header/header-menu.module";
import {ServerdockerRoutingModule} from "./serverdocker/serverdocker-routing.module";
import {AnalyticsModule} from "./analytics/analytics.module";
import {MiddlewaresModule} from "./middlewares/middlewares.module";
import {NFVTraceModule} from "./nfvTrace/nfvTrace.module";
import {PoliciesModule} from "./policies/policies.module";


@NgModule({
    imports: [
        CommonModule,
        ServerdockerModule,
        HeaderMenuModule,
        ServerdockerRoutingModule,
        BodyRoutingModule,
        AnalyticsModule,
        ApplicationsModule,
        MiddlewaresModule,
        NFVTraceModule,
        PoliciesModule,
        SharedModule
    ],
    declarations: [BodyComponent],
    exports: [BodyComponent],
    providers: []
})
export class BodyModule {
}
