import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {ApplicationsComponent} from "./applications/applications.component";
import {BodyComponent} from "./body.component";
import {ServerdockerComponent} from "./serverdocker/serverdocker.component";
import {ServicelistComponent} from "./serverdocker/servicelist.component/servicelist.component";
import {ServiceInfoComponent} from "./serverdocker/serviceInfo.component/serviceInfo.component";
import {OverviewComponent} from "./serverdocker/serviceInfo.component/overview/overview.component";
import {DiskComponent} from "./serverdocker/serviceInfo.component/disk/disk.component";
import {AggregateCPUUsageComponent} from "./serverdocker/serviceInfo.component/aggregateCPUUsage/aggregateCPUUsage.component";
import {MemoryUsageComponent} from "./serverdocker/serviceInfo.component/memoryUsage/memoryUsage.component";
import {FileSystemComponent} from "./serverdocker/serviceInfo.component/fileSystem/fileSystem.component";
import {NetworkInterfaceComponent} from "./serverdocker/serviceInfo.component/networkInterface/networkInterface.component";
import {ProcessInformationComponent} from "./serverdocker/serviceInfo.component/processInformation/processInformation.component";
import {AnalyticsComponent} from "./analytics/analytics.component";
import {MiddlewaresComponent} from "./middlewares/middlewares.component";
import {PoliciesComponent} from "./policies/policies.component";
import {NFVTraceComponent} from "./nfvTrace/nfvTrace.component";
import {PolicyComponent} from "./policies/policy/policy.component";

@NgModule({
    imports: [
        RouterModule.forChild([
            {
                path: '',
                redirectTo: 'body/applications',
                pathMatch: 'full'
            },
            {
                path: 'body/serverdocker',
                redirectTo: 'body/serverdocker/servicelist',
                pathMatch: 'full'
            },
            {
                path: 'body/serverdocker/serviceInfo',
                redirectTo: 'body/serverdocker/serviceInfo/overview',
                pathMatch: 'full'
            },
            {
                path: 'body/policies',
                redirectTo: 'body/policies/policy',
                pathMatch: 'full'
            },
            {
                path: 'body',
                component: BodyComponent,
                children: [
                    {
                        path: 'applications',
                        component: ApplicationsComponent
                    },
                    {
                        path: 'serverdocker',
                        component: ServerdockerComponent,
                        children: [
                            {
                                path: 'servicelist',
                                component: ServicelistComponent
                            },
                            {
                                path: 'serviceInfo',
                                component: ServiceInfoComponent,
                                children: [
                                    {
                                        path: 'overview',
                                        component: OverviewComponent
                                    },
                                    {
                                        path: 'aggregateCPUUsage',
                                        component: AggregateCPUUsageComponent
                                    },
                                    {
                                        path: 'memoryUsage',
                                        component: MemoryUsageComponent
                                    },
                                    {
                                        path: 'fileSystem',
                                        component: FileSystemComponent
                                    },
                                    {
                                        path: 'disk',
                                        component: DiskComponent
                                    },
                                    {
                                        path: 'networkInterface',
                                        component: NetworkInterfaceComponent
                                    },
                                    {
                                        path: 'processInformation',
                                        component: ProcessInformationComponent
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        path: 'analytics',
                        component: AnalyticsComponent
                    },
                    {
                        path: 'middlewares',
                        component: MiddlewaresComponent
                    },
                    {
                        path: 'policies',
                        component: PoliciesComponent,
                        children: [
                            {
                                path: 'policy',
                                component: PolicyComponent
                            }
                        ]
                    },
                    {
                        path: 'nfvTrace',
                        component: NFVTraceComponent
                    },

                ]
            }
        ])
    ],
    exports: [RouterModule]
})
export class BodyRoutingModule {
}
