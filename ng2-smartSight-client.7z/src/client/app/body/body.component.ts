import { Component, OnInit } from '@angular/core';


/**
 * This class represents the lazy loaded HomeComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'sd-body',
  templateUrl: 'body.component.html',
  styleUrls: ['body.component.css'],
})
export class BodyComponent implements OnInit {

  constructor() {}

  ngOnInit() {

  }


}
