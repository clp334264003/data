import {Component, Input} from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'empty-table',
    templateUrl: 'empty-table.component.html',
    styleUrls: ['empty-table.component.css']
})
export class EmptyTableComponent {
}