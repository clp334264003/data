import {Injectable}     from '@angular/core';


@Injectable()
export class VariableService {
    constructor() {

    }
    getMockFlag() {
        // return true;
        return false;
    }


}

