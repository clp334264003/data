import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import {BodyComponent} from "./body/body.component";

@NgModule({
  imports: [
    RouterModule.forRoot([
      /* define app module routes here, e.g., to lazily load a module
         (do not place feature module routes here, use an own -routing.module.ts in the feature instead)
       */
      {path: '', redirectTo: 'body', pathMatch: 'full'},
      { path: 'body', component: BodyComponent }
    ])
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }

