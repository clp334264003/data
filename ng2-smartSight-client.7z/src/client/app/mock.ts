export class MockCfg {

    public static baseUrl:string = '';
    public static registerUrl:String = '/api/register';
    public static authenticateUrl:String = '/api/authenticate';
    public static accountUrl:String = '/api/account';


    public static base8084Url: string = 'http://10.62.100.241:8084';
    public static base8083Url: string = 'http://10.62.100.241:8083';
    public static serverstatsUrl: string = '/serverstats.pinpoint';

    public static serverMockdataSourceURL() {
        return "http://" + "localhost" + ":5555";
    }

    public static getMockFlag() {
        return true;
        // return false;
    }

    public static getRealIp() {
        return "10.62.100.151";
    }

    public static dataSourceURL() {
        if (document.location.hostname == 'localhost') {
            return "http://" + this.getRealIp() + ":8084";
        } else {
            return "http://" + document.location.hostname + ":8084";
        }
    }

    public static dataDBSourceURL() {
        if (document.location.hostname == 'localhost') {
            return "http://" + this.getRealIp() + ":8081";
        } else {
            return "http://" + document.location.hostname + ":8081";
        }
    }

    public static dataSourcePolicyURL() {
        if (document.location.hostname == 'localhost') {
            return "http://" + this.getRealIp() + ":8083";
        } else {
            return "http://" + document.location.hostname + ":8083";
        }
    }
}
