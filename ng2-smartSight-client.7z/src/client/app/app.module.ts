import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {APP_BASE_HREF} from '@angular/common';
import {HttpModule} from '@angular/http';
import {AppComponent} from './app.component';
import {AppRoutingModule} from './app-routing.module';
import {SharedModule} from './shared/shared.module';

import {BodyModule} from "./body/body.module";
import {NgbModule} from "@ng-bootstrap/ng-bootstrap";
import {AUTH_PROVIDERS, provideAuth} from "angular2-jwt";



@NgModule({
    imports: [
        BrowserModule,
        HttpModule,
        AppRoutingModule,
        BodyModule,
        NgbModule.forRoot(),
        SharedModule.forRoot()],
    declarations: [
        AppComponent
    ],
    // providers: [{
    //     provide: APP_BASE_HREF,
    //     useValue: '<%= APP_BASE %>'
    // }],
    providers: [
        AUTH_PROVIDERS,
        provideAuth({
            headerName: "authorization",
            headerPrefix: "Bearer",
            tokenName: "id_token",
            tokenGetter: (() => window.localStorage.getItem('authenticationToken')),
            globalHeaders: [{'Content-Type':'application/json'}],
            noJwtError: false,
            noTokenScheme: false
        }),
        {
            provide: APP_BASE_HREF,
            useValue: '<%= APP_BASE %>'
        },
    ],
    bootstrap: [AppComponent]

})
export class AppModule {
}
